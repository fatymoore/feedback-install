App.UsersListCollection = Backbone.Collection.extend({
    model: UserModel,
    selectedUserEl: null,
    selectedUserModel: null,
    talkingTo: null,
    events: {
        'unselectAllUsers':'unselectAllUsers',
        'selectCurrentUser':'selectCurrentUser'
    },
    initialize : function(){
        //TID.log.debug("initialize UsersListCollection");
    },
    saveContactOrder: function() {
        TID.log.debug("saveContactOrder UsersListCollection");
        Storage.saveUsersList(window.users);
    },
    unselectAllUsers: function () {
        TID.log.debug("unselectAll UsersListCollection");
        $('#contactsList').find('li .contact-handler').each(function(){
            $(this).removeClass('selected');
        });
    },
    unselectCurrentUser: function(){
        TID.log.debug("unselectCurrentUser UsersListCollection");
        if (this.selectedUserEl) {
            this.selectedUserEl.removeClass('selected');
        }
    },
    selectCurrentUser: function(selectedUserEl){
        TID.log.debug("selectCurrentUser UsersListCollection");
        if (App.inboxView.collection.selectedUserModel != null){
            var m = $(App.inboxView.collection.selectedUserEl);
            var htm = m.find('.contact-handler');
            htm.addClass('selected');
        }
    },
    increaseMsgCount: function(msisdn){
        TID.log.debug("increaseMsgCount UsersListCollection "+ msisdn);
        this.updateMsgCount('msisdn', msisdn);
    },
    updateMsgCount: function (attribute, value) {
        TID.log.debug("updateMsgCount UsersListCollection");
        var m = this.collection;
        return this.some(function(m) {
            if (m.get(attribute) === value){
                var unreadMessages = m.get('unreadMessages') + 1;
                m.set({'unreadMessages':unreadMessages});
                return true;
            }
            else {
                return false;
            }
        });
    },
    increaseTimestamp: function(msisdn){
        TID.log.debug("increaseTimestamp UsersListCollection "+ msisdn);
        this.updateTimestamp('msisdn', msisdn);
    },
    updateTimestamp: function(attribute, value){
        TID.log.debug("updateTimestamp UsersListCollection");
        var m = this.collection;
        return this.some(function(m) {
            if (m.get(attribute) === value){
                var lastEvent = new Date().getTime();
                m.set({'lastEvent':lastEvent},{silent: true});
                return true;
            }
            else {
                return false;
            }
        });
    }
});

App.sortUsersCollection = Backbone.Collection.extend({
    val : null,
    initialize : function(models, options) {
        //TID.log.debug("initialize sortUsersCollection");
        this.val = options.sv;
    },
    comparator: function(model){
        //TID.log.debug("comparator sortUsersCollection");
        switch (this.val){
            case 1:
                return -model.get('lastEvent');
                break;
            case 2:
                return [model.get('name'), model.get('surname')];
                break;
            case 3:
                return -model.get('presence');
                break;
        }
    }
});

App.InboxView = Backbone.View.extend({
    el : 'contacts-container',
    sortVar: 1,
    events: {
        'sortUsers':'sortUsers'
    },
    initialize : function(divLayer) {
        //TID.log.debug("initialize InboxView");
        this.collection = new App.UsersListCollection;
        $('#btnTimeOrder').addClass("selected");
        this.loadUsers();
        this.sortUsers(1);
    },
    render : function(){
        TID.log.debug("render InboxView");
        var contacsLayout;
        var collection = this.collection;
        contacsLayout = $('#contactsList');
        contacsLayout.empty();

        collection.each(function(user){
            TID.log.debug(user.get('msisdn'));
            var view = new App.UserView({
                model:user,
                collection: collection
            });
            contacsLayout.append(view.render().el);
        });

        this.collection.saveContactOrder();
    },
    loadUsers : function(){
        //TID.log.debug("loadUsers InboxView");
        this.collection.add(users); // TODO Read users from LocalStorage
    },
    sortUsers: function(val){
    	//TID.log.debug("sortUsers InboxView");
        this.sortVar = val;

        switch (val) {
            case 1:
                  var t = this.collection.talkingTo;
                  var col = this.collection.where({'msisdn':t});
                  if (col.length > 0) {
                      this.collection.remove(col[0], {silent: true, sort: false});
                      var sortedCol = new App.sortUsersCollection(this.collection.models,{sv:1}); // sort collection
                      this.collection.reset(sortedCol.models, {silent: true});
                      this.collection.unshift(col[0], {silent: true});
                  } else {
                      var sortedCol = new App.sortUsersCollection(this.collection.models,{sv:1}); // sort collection
                      this.collection.reset(sortedCol.models, {silent: true});
                  }
                  break;
            case 2:
                  var sortedCol = new App.sortUsersCollection(this.collection.models,{sv:2});
                  this.collection.reset(sortedCol.models, {silent: true});
                  break;
            case 3:
                  var sortedCol = new App.sortUsersCollection(this.collection.models,{sv:3});
                  this.collection.reset(sortedCol.models, {silent: true});
                  break;
        }

        this.render();
    },

    messageSent: function(msisdn) {
        this.collection.increaseTimestamp(msisdn);
        App.inboxView.sortUsers(1);
        var lastSelectedUser = this.collection.selectedUserModel;
        lastSelectedUser.set('listStatus',0,{silent: true});
    },

    increaseMsgCount: function(msisdn) {
        TID.log.debug("increaseMsgCount InboxView");
        var msisdnTalkingUser = this.collection.selectedUserModel.get('msisdn');

        this.collection.increaseTimestamp(msisdn);

        if (msisdn != msisdnTalkingUser) {
            this.collection.increaseMsgCount(msisdn);
        }

        if(this.sortVar == 1) {
           this.sortUsers(1);
        }
    },
    increaseCallcount: function(){
        TID.log.debug("increaseCallcount InboxView");
    },
    loadUsers : function(){
        TID.log.debug("loadUsers InboxView");
        this.collection.add(users); // TODO Read users from LocalStorage
    },
    addContactsFromAddressBook: function() {
         if(!navigator.mozContacts){
            TID.log.debug("There is no address book");
            return;
		}
		TID.log.debug('Reading address book');

		var contactsLayout = $('#contacts2List');
		contactsLayout.empty();
		
		var options = {
			sortBy: 'familyName',
			sortOrder: 'ascending'
		};
		
		var request = navigator.mozContacts.find(options);
		request.onsuccess = function() {
			contactsLayout.empty();
			var list='';
			request.result.forEach(function(result){
				result.tel.forEach(function(tel, idx){
					TID.log('tel %s: %o', idx, tel.value);
				});
			
				var user =  {
			        "listStatus": 0,
			        "msisdn": result.tel[0].value,
			        "landline": result.tel[0].value,
			        "name": Yarn.TextConversions.escapeSpecialCharacters(result.name),
			        "surname": null,
			        "screenName": Yarn.TextConversions.escapeSpecialCharacters(result.name),
			        "email": "javier@tume.com",
			        "catchphrase": "Address Book",
			        "presence": 1,
			        "userId": null,
			        "avatar": null,
			        "unreadCalls": 0,
			        "unreadMessages": 0,
			        "lastEvent": 0
			    };

				list += window.myAppRouter.getTemplateContacts(user);
			});

			$('#contacts2List').append(list);

		};

		request.onerror = function() {
			TID.log.debug("error obteniendo contactos");
		};
    }
});

var users = [
	{
        "listStatus": 0,
        "msisdn": "447403177856",
        "landline": null,
        "name": "Belen",
        "surname": "Albeza",
        "screenName": "Belen",
        "email": "belen.albeza@o2.com",
        "catchphrase": "Waka waka",
        "presence": 1,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 0,
        "lastEvent": 0
    }, {
        "listStatus": 0,
        "msisdn": "447718188613",
        "landline": null,
        "name": "Belen",
        "surname": "(Trabajo)",
        "screenName": "Belen (Trabajo)",
        "email": "belen.albeza@telefonica.com",
        "catchphrase": "Waka waka eh eh",
        "presence": 1,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 0,
        "lastEvent": 0
    }, {
        "listStatus": 0,
        "msisdn": "34618540232",
        "landline": null,
        "name": "Adolfo",
        "surname": null,
        "screenName": "Adolfo_QA",
        "email": "adolfo@tume.com",
        "catchphrase": "Adolfo QA",
        "presence": 0,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 2,
        "lastEvent": 0
    }, {
        "listStatus": 0,
        "msisdn": "34675523726",
        "landline": null,
        "name": "Roberto",
        "surname": "1",
        "screenName": "Roberto",
        "email": "roberto1@tume.com",
        "catchphrase": "Roberto 1",
        "presence": 0,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 3,
        "lastEvent": 0
    }, {
        "listStatus": 0,
        "msisdn": "34679997962",
        "landline": null,
        "name": "Sergio",
        "surname": "Artero",
        "screenName": "Sergio Artero",
        "email": "sergio@tume.com",
        "catchphrase": "Forever working",
        "presence": 1,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 0,
        "lastEvent": 0
    }, {
       "listStatus": 0,
        "msisdn": "34619125646",
        "landline": "34619125646",
        "name": "Roberto",
        "surname": "2",
        "screenName": "Roberto 2",
        "email": "roberto2@tume.com",
        "catchphrase": "Forever working, all night and all day",
        "presence": 0,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 0,
        "lastEvent": 0
    }, {
        "listStatus": 0,
        "msisdn": "34679931196",
        "landline": "34679931196",
        "name": "Ambrin",
        "surname": "Ambrin",
        "screenName": "Ambrin",
        "email": "ambrin@tume.com",
        "catchphrase": "Forever testing",
        "presence": 1,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 4,
        "lastEvent": 0
    }, {
        "listStatus": 0,
        "msisdn": "34646437919",
        "landline": null,
        "name": "Jorge",
        "surname": "Serna",
        "screenName": "JorgeSerna",
        "email": "jorgeSerna@tume.com",
        "catchphrase": "Forever testing",
        "presence": 0,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 5,
        "lastEvent": 3
    }, {
        "listStatus": 0,
        "msisdn": "34696876382",
        "landline": null,
        "name": "Andres",
        "surname": "Tablet",
        "screenName": "Flipas",
        "email": "ajsoriar@tume.com",
        "catchphrase": "Android Tablet",
        "presence": 1,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 0,
        "lastEvent": 1
    }, {
        "listStatus": 0,
        "msisdn": "34646014586",
        "landline": null,
        "name": "Fatima",
        "surname": "Fatima",
        "screenName": "Fatima",
        "email": "fatima@tume.com",
        "catchphrase": "Forever testing",
        "presence": 0,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 1,
        "lastEvent": 2
    }, {
        "listStatus": 0,
        "msisdn": "34610370213",
        "landline": null,
        "name": "Andres",
        "surname": "WEB App",
        "screenName": "Flipas",
        "email": "ajsoriar@tume.com",
        "catchphrase": "Tu Me WEB",
        "presence": 0,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 0,
        "lastEvent": 0
    }, {
        "listStatus": 0,
        "msisdn": "34629116070",
        "landline": null,
        "name": "Guillaume",
        "surname": "PARIS",
        "screenName": "Guillaume",
        "email": "guillaume@tume.com",
        "catchphrase": "Tu Me WEB",
        "presence": 0,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 0,
        "lastEvent": null
    }, {
        "listStatus": 0,
        "msisdn": "34647606749",
        "landline": null,
        "name": "Juan",
        "surname": "de Bravo",
        "screenName": "iJuan",
        "email": "jdbd@tid.es",
        "catchphrase": "OLA K ASE",
        "presence": 1,
        "userId": null,
        "avatar": null,
        "unreadCalls": 0,
        "unreadMessages": 0,
        "lastEvent": null
    }
];
