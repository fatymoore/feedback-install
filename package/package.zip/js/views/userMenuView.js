App.UserMenuView = Backbone.View.extend({

    el: 'body', 
    events: {
        'click #user-menu-arrow': 'showUserMenu',  
        'click #mnu-status-online': 'setStatusOnline', 
        'click #mnu-status-offline': 'setStatusOffline',
        'click #mnu-status-away': 'setStatusAway',
        'click #mnu-status-busy': 'setStatusBusy',
        'click #mnu-add-minutes': 'addMinutes',
        'click #mnu-settings': 'gotoSettings',
        'click #mnu-link-to-talk': 'linkToTalk',
        'click #mnu-sign-out': 'signOut'
    },
    
    initialize: function() {
        TID.log.debug("-> UserMenuView -> initialize");
        //this.render;      
    },
    render: function() {
        TID.log.debug("-> UserMenuView -> render");
    },  
     
    showUserMenu: function() {
        TID.log.debug("-> AppView -> mostrar menu");
        $('#options').fadeToggle(300);
    },
    
    setStatusOnline: function() {
        TID.log.debug("-> UserMenuView -> setStatusOnline");
        this.closeMenu();
        mainView.openSIPConnection(); //LandingView has the logic
    },  
     
    setStatusOffline: function() {
        TID.log.debug("-> UserMenuView -> setStatusOffline");
        this.closeMenu();
        RtcManager.disconnect(); 
    },  
     
    setStatusAway: function() {
        TID.log.debug("-> UserMenuView -> setStatusAway");
        this.closeMenu();
    },  
     
    setStatusBusy: function() {
        TID.log.debug("-> UserMenuView -> setStatusBussy");
        this.closeMenu();
    },  
     
    addMinutes: function(){
        TID.log.debug("-> UserMenuView -> addMinutes");
        this.closeMenu();

    },
    gotoSettings: function(){
        TID.log.debug("-> UserMenuView -> gotoSettings");
        //window.myAppRouter.navigate('settings',true);
        window.myAppRouter.showSettings();
        this.closeMenu();
    },
    linkToTalk: function(){
        TID.log.debug("-> UserMenuView -> linkToTalk");
        this.closeMenu();

    },
    signOut: function(){
        TID.log.debug("-> UserMenuView -> signOut");
        RtcManager.disconnect(); 
    },
    closeMenu: function(){
        $('#options').fadeOut(300);
    }

});
