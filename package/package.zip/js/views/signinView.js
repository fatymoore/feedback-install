var SigninView = Backbone.View.extend( {

    initialize : function () {
        //TID.log.debug("Init SigninView");
    },

    events : { /* DOM events go here */
        'click #buttonLogIn': 'signIn',
        //'click #buttonContacts': 'readAddressBook',
        'click #buttonRegister': 'registerPage'
    },

    signIn: function ( e ) {
        //TODO check user/password
        this.saveCookies();
        this.gotoHome();

    },

    saveCookies: function () {
        var user = this.$el.find('#inputEmail').val();
        var password = this.$el.find('#inputPassword').val();

        $.cookie( 'username', user );
        $.cookie( 'password', password );
    },

    sendSIPTestMessage: function () {
        RtcManager.sendTextMessage('this is a test (sent from TuMe web)');
    },

    gotoHome: function () {
        TID.log.debug('Going to Home Page');

        if ( $(window).width() < 480 ) {
             window.location = 'main-owd.html';
        } else {
             window.location = 'index.html';
        }

    },

    registerPage: function () {
        TID.log.debug('Going to Register Page');

        if ( $(window).width() < 480 ) {
            window.location = 'register-owd.html';
        } else {
            window.location = 'register.html';
        }
    }
    /*
    readAddressBook: function(){
          TID.log.debug('Reading address book');

          $('#listContacts').html('');

          var options = {
            sortBy: 'familyName',
            sortOrder: 'ascending'
          };

          var request = navigator.mozContacts.find(options);
          request.onsuccess = function() {
            TID.log.debug("contactos obtenidos: " + request.result.length);

            var list='';
            request.result.forEach(function(result){
              result.tel.forEach(function(tel, idx){
                TID.log('tel %s: %o', idx, tel.value)
              });
              list+='<li>' + escapeSpecialCharacters(result.name) + ' - ' + result.tel[0].value+'</li>';
            });

            $('#listContacts').append(list);

          };

          request.onerror = function() {
            console.log("error obteniendo contactos");
          }
    }
    */

} );

/**
 * Creates de contact view in Backbone.
 */
var initSigninPage = function () {
    signinView = new SigninView( {
        el: $("form#form-horizontal")
    } );
};

$( document ).ready( function () {
    initSigninPage();
});
