App.PictureView = Backbone.View.extend({
    initialize: function(pictureID) {
        this.createButtonEvents();
        this.showBlackBackground();
        this.showPicture(pictureID);   
    },
    showBlackBackground: function() {
        $('#imgViewerBGLayer').addClass('show'); 
    },
    showPicture: function(pictureID){
        $('#realPicture').attr('src', 'img/shared/' + pictureID); 
        $('#viPictureContainer').addClass('show');
    },
    removeView: function() {

        this.removeButtonEvents();
        
        $('#viPictureContainer').fadeOut(400,function(){
            $('#viPictureContainer').removeClass('show');
        });
        
        $('#imgViewerBGLayer').fadeOut(400,function() {
            $('#imgViewerBGLayer').removeClass('show');
        });
        
        this.remove();
    
    },
    removeButtonEvents: function(){
        $('#imgViewerBGLayer').unbind('click');
        $('#btnViPictureClose').unbind('click');
    },
    createButtonEvents: function(){

        $('#imgViewerBGLayer').click(function() {        
            window.pictureViewer.removeView();
        });
        
        $('#btnViPictureClose').click(function() {    
            window.pictureViewer.removeView();
        });

    }

});