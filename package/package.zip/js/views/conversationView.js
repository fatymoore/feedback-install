var conversationView;

var initConversationPage = function(userMsisdn, layer) {
    if ( !conversationView ){
        conversationView = new ConversationView({ el: $('#'+layer), msisdn: userMsisdn });
    }else{
        conversationView.loadConversation({ el: $('#'+layer), msisdn: userMsisdn });
    }
};

var ConversationView = Backbone.View.extend({
    replies:				null,
    eventType:				null,
    msisdn:					null,
    audio:					null,
    image:					null,

    events: {
        'click #btnChat,#btnCamera,#btnPhone,#btnLocation,#btnMicrophone,#btnSticker': 'enableButton',
        'click #btnSend':										'sendChatButton',
        'keypress #txt-input, #photoCaption, #audioCaption':	'keyPressed',
        'keyup #txt-input':         							'valueChange',
        'focus #txt-input, #photoCaption':						"onFocus",
        'blur #txt-input, #photoCaption':						"onBlur",
        'click #btnCamera':										'showPhotoBox',
        'click #inputFile':										'cleanImageInput',
        'change #inputFile':									'handleImage',
        'click #btnCloseImg':									'deletePhoto',
        'click #btnLocation':									'showLocationBox',
        'click #locationSearchBox':								'searchRecommendation',
        'click #msg-load':										'resendChat',
        'click #btnMicrophone':									'showAudioBox',
        'click #selectAudioPane':								'openAudioFileBrowser',
        'change #audioFileBrowser':								'handleAudio',
        'click #playPause':										'playAudio',
        'click #reRecord':										'reRecord',
        'click .audioMessageButton':							'playPauseMessageAudio',
        'click  #msg-trash':									'deleteItemConversation',
    },
    onFocus: function(parameters) {
        $('#input-holder').addClass('selected');
        $('#photoCaption').addClass('selected');
    },
    onBlur: function(parameters) {
        $('#input-holder').removeClass('selected');
        $('#photoCaption').removeClass('selected');
    },
    initialize: function(parameters) {
        this.loadConversation(parameters);
        this.disableChatButton();
    },
    loadConversation: function(parameters){
        this.msisdn = parameters.msisdn;
        this.eventType = EventType.text;
        this.model = new MessagesList();
        this.loadChatMessages();
        this.scrollChat();
    },
    enableButton: function(event) {
        var iconId = '#' + event.currentTarget.id;
        event.preventDefault();

        if ($(iconId).hasClass('selected')) {
            if($('.inputBoxOwd')){
                $('.inputBoxOwd').hide();
                $(iconId).removeClass('selected');
            }
        } else {
            $('#container div').removeClass('selected');
            $(iconId).addClass('selected');
            //mostrar la caja de texto
            if($('.inputBoxOwd')){
                $('.inputBoxOwd').show();
                $('.inputBoxOwd').focus();
            }
        }
        this.$el.find('.input-holder').removeClass('photo').removeClass('location').removeClass('audio');
        this.eventType = EventType.text;
        this.disableChatButton();
    },

    keyPressed: function(e) {
        var keycode = (e.keyCode ? e.keyCode : e.which);
        if (keycode == '13') {
            e.preventDefault();
            conversationView.sendChat();
        }
    },

    valueChange: function() {
        var val = document.getElementById('txt-input').value.length;
        if ( val > 0 ) {
            this.enableChatButton();
        } else {
            this.disableChatButton();
        }
    },

    loadChatMessages: function() {
        var messagesList = Storage.getUserConversation(this.msisdn);
        if (messagesList) {
            for (i = 0; i < messagesList.length; i++) {
                this.model.add(Parser.MessageObjectToBackboneModel(messagesList[i]));
            }
        }
        this.render();
    },

    render: function() {
        if (this.model) {
            var conv = $('#chatpane');
            this.$el.find('#chatpane ul').html('');
            for (i = 0; i < this.model.length; i++) {
                this.showMessageInPane(this.model.at(i));
            }
            $('#chatpane').animate({scrollTop: $('#chatpane').prop('scrollHeight')}, 1, function() {
                conv.animate({opacity: 1, scale: 1, paddingBottom: 0, marginTop: 0}, 400);
            });
        }
    },

    /* Draw a message using underscore template for messages*/
    showMessageInPane: function(jsonMessage) {
        var template;

        switch (jsonMessage.eventType) {
            case EventType.text:
                template = _.template($('#tmpl_mesage_text').html(), jsonMessage);
                this.$el.find('#chatpane ul.conversation').append(template);
                break;
            case EventType.image:
                template = _.template($('#tmpl_mesage_text_and_picture').html(), jsonMessage);
                this.$el.find('#chatpane ul.conversation').append(template);
                break;
            case EventType.location:
                template = _.template($('#tmpl_mesage_location').html(), jsonMessage);
                this.$el.find('#chatpane ul.conversation').append(template);
                Yarn.Geo.showLocationAsImageMessage('.id'+jsonMessage.timeReceived, jsonMessage.latitude, jsonMessage.longitude);
                break;
            case EventType.audio:
                template = _.template($('#tmpl_message_audio').html(), jsonMessage);
                this.$el.find('#chatpane ul.conversation').append(template);
                break;
        }
        this.$el.find('#chatpane ul.conversation li').last().addClass('before');
        this.setSpace(jsonMessage.eventType);
    },

    /* stores the message in model and in Local */
    saveMessage: function(messageEvent, msisdn) {
        Storage.saveConversationMessage(msisdn, messageEvent);
        this.model.add(messageEvent);
    },

    deleteItemConversation: function(event){
    	var myMsisdn = $.cookie('username');
    	var cid = $(event.currentTarget.parentElement.parentElement).attr('id');
    	var callId = $(event.currentTarget.parentElement.parentElement).attr('callId');
    	
    	ApiClient.deleteHistoryItem(myMsisdn, cid, this.msisdn, this.deleteItemResponse, this.deleteErrorCode);
    },

    deleteItemResponse: function(msisdn, cid ) {
    	$('#' + cid).remove();
        /*Borrar del localStorage*/
    	
    	Storage.deleteConversationItem(msisdn, cid);
    },

    deleteErrorCode: function(response) {
    	alert(i18n.getPropertyValue(response));
    },

    /* action fired when clickin on 'send' button */
    sendChatButton: function(e) {
        var objBtn = $('#btnSend');
        if (!objBtn.hasClass('disabled')) conversationView.sendChat();

        switch (this.eventType) {
            case EventType.location:
                $('#locationMap').css('display', 'block');	
                $('#locationMap').html('<span>' + i18n.getPropertyValue('clickLocation') +'</span>');
                $('#locationSearchBox').html('');

                break;
            case EventType.audio:
                $('#btnMicrophone').trigger('click');
                break;
        }
        this.disableChatButton();
    },

    disableChatButton: function() {
        this.$el.find('#btnSend').addClass('disabled');
    },

    enableChatButton: function() {
        this.$el.find('#btnSend').removeClass('disabled');
    },
    refreshAddressBox: function(namePlace, address) {
    	if (namePlace == '') {
    		$('#locationSearchBox').html(address);
    	} else {
    		$('#locationSearchBox').html(namePlace + ' - ' + address);
    	}
    },

    sendChat: function() {
        if (conversationView.validateText()) {
            var messageEvent = null;

            switch (this.eventType) {
                case EventType.text:
                    var typedText = $('#txt-input').val();
                    messageEvent = new MessageEvent(EventType.text); //Store in LocalStorage
                    messageEvent.setMessage(typedText);

                    if(RtcManager.status != Yarn.PresenceStatus.Offline) {
                        //send to SIP Server
                        RtcManager.sendTextMessage(this.msisdn, typedText, messageEvent.cid);
                    }

                    $('#txt-input').val('');
                    break;

                case EventType.image:
                    if (this.image === null) {
                        messageEvent = new ImageMessage();
                        var thumbailData = this.generateThumbnail(this.getCurrentThumbnail());
                        messageEvent.thumbnail = thumbailData.imgData;
                        messageEvent.width = thumbailData.imgWidth;
                        messageEvent.height = thumbailData.imgHeight;

                        // Get caption from form only for new image message
                        if($('#photoCaption').val()){
                            messageEvent.caption = $('#photoCaption').val();
                        }
                    }
                    else {
                        // Get image from the element previsously set in resendChat
                        messageEvent = this.image;
                        this.image = null;
                    }
                    this.deletePhoto();

                    $('#photoCaption').val('');

                    if (RtcManager.status != Yarn.PresenceStatus.Offline) {
                    	StorageManager.sendPicture(messageEvent.thumbnail, this.rtcSendImage); //Should return the uri, and send it via SIP                        
                    	RtcManager.sendImageMessage(this.msisdn, messageEvent.cid, messageEvent.thumbnail, messageEvent.caption);
                    }

                    break;

                case EventType.location:
                	$('#locationMap, #locationSearchBox, #advancedMap').hide();

                    messageEvent = new LocationMessage();
                    messageEvent.latitude = Yarn.Geo.currentLatitude;
                    messageEvent.longitude = Yarn.Geo.currentLongitude;

                    if (!Yarn.Geo.currentAddress) {
                    	Yarn.Geo.getCurrentAddress();
                    }

                    messageEvent.address = Yarn.Geo.currentAddress;
                    messageEvent.namePlace = Yarn.Geo.namePlace;

                    if(RtcManager.status != Yarn.PresenceStatus.Offline) {
                        //send to SIP Server
                    	StorageManager.sendAudio(messageEvent.thumbnail, this.rtcSendAudio); //Should return the uri, and send it via SIP
                        RtcManager.sendLocationMessage(this.msisdn, messageEvent.latitude, messageEvent.longitude, messageEvent.address, messageEvent.cid);
                    }

                    break;

                case EventType.audio:
                    AudioController.stop();
                    messageEvent = new  AudioMessage();
                    messageEvent.duration = $('#duration').html();
                    messageEvent.body = $('#audioCaption').val();
                    messageEvent.uri = 'https://storage.yarnapp.com/StorageManager/BlobStorage?blobId=ff9edcb5-db7b-41bb-9342-64bcc852c091';
                    $('#audioCaption').val('');

                    if(RtcManager.status != Yarn.PresenceStatus.Offline) {
                        StorageManager.sendAudio(AudioController.audioData, this.rtcSendAudio); //Should return the uri, and send it via SIP
                        RtcManager.sendAudioMessage(this.msisdn, messageEvent.cid, messageEvent.uri, messageEvent.duration);
                    }

                    break;
            	}

            messageEvent.callId = RtcManager.callId();

            this.saveMessage(messageEvent, this.msisdn);//save in localStorage
            this.showMessageInPane(messageEvent);
            this.setSpace(this.eventType);
            this.animateChatAppearance();
/*            
            conversationView.saveMessage(messageEvent, this.msisdn);//save in localStorage
            conversationView.showMessageInPane(messageEvent);
            conversationView.setSpace(this.eventType);
            conversationView.animateChatAppearance();
*/
            App.inboxView.messageSent(this.msisdn);

            // If user offline set Error on Message
            if(RtcManager.status == Yarn.PresenceStatus.Offline) {
                this.receiveStatusError(this.msisdn, messageEvent.cid);
            }
        }
        else {
            TID.log.debug('void text! in ' + this.msisdn);
        }
    },

    rtcSendImage: function(response) {
    	if (response && response != '') {
    		RtcManager.sendImageMessage(this.msisdn, messageEvent.cid, messageEvent.thumbnail, messageEvent.caption, response);
    	} else {
    		// error save image to Storage
    	}
    },
    
    rtcSendAudio: function(response) {
    	if (response && response != '') {
    		RtcManager.sendAudioMessage(this.msisdn, messageEvent.cid, messageEvent.uri, messageEvent.duration);
    		RtcManager.sendAudioMessage(this.msisdn, messageEvent.cid, response, messageEvent.duration);
    	} else {
    		// error save image to Storage
    	}
    },

    animateChatAppearance: function() {
        var li;
        this.scrollChat();
        li = this.$el.find('#chatpane ul.conversation li').last();
        li.addClass('after');
    },

    scrollChat: function() {
        App.Layout.conversationTopMargin();
        $('#chatpane').animate({scrollTop: $('#chatpane').prop('scrollHeight')});
    },

    validateText: function() {
       if (conversationView.eventType == EventType.text) {
            var msg = $('#txt-input').val();

            msg = conversationView.deleteCharacterHTML(msg);
            msg = conversationView.linkify(msg);
            $('#txt-input').val(msg);

            if (msg.trim() === '') return false;
       }
       else if(conversationView.eventType == EventType.image) {
            return (this.$el.find('#pictureContainer').find('img').length > 0);
       }
       else if(conversationView.eventType == EventType.audio) {
         return ($('#audioFileBrowser').val().length > 0);
       }

       return true;
    },

    deleteCharacterHTML: function(cadena) {
        var txtWithEnter = cadena.replace(/\n/gi, '');
        
        var txtWithHTMLLabel = Yarn.TextConversions.deleteHTMLLabel(txtWithEnter, '<a');
        txtWithHTMLLabel = Yarn.TextConversions.deleteHTMLLabel(txtWithHTMLLabel, '</a');
        
        txtWithHTMLLabel = Yarn.TextConversions.replaceAll(txtWithHTMLLabel, '<', '&lt');
        txtWithHTMLLabel = Yarn.TextConversions.replaceAll(txtWithHTMLLabel, '>', '&gt');
        return txtWithHTMLLabel;
    },
    
    linkify: function (inputText) {
        //URLs starting with http://, https://, or ftp://
        var replacePattern1 = /(\b(https?|ftp):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gim;
        var replacedText = inputText.replace(replacePattern1, '<a href="$1" target="_blank">$1</a>');

        //URLs starting with www. (without // before it, or it'd re-link the ones done above)
        var replacePattern2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
        var replacedText = replacedText.replace(replacePattern2, '$1<a href="http://$2" target="_blank">$2</a>');

        //Change email addresses to mailto:: links
        var replacePattern3 = /^([a-zA-Z0-9._+%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}|museum)$/gim;
        var replacedText = replacedText.replace(replacePattern3, '<a href="mailto:$1">$1</a>');
        return replacedText
    },

    showPhotoBox: function() {
        this.$el.find('.input-holder').removeClass().addClass('input-holder').addClass('photo');
        this.eventType = EventType.image;
        this.deletePhoto();
    },
    handleImage: function(evt) {
        var files = evt.target.files;
        // Loop through the FileList and render image files as thumbnails.
        conversationView.$el.find('.input-holder').addClass('imageSelected');
        conversationView.$el.find('.input-holder span').css('display', 'block');

        $('#photoPaneTextArea span').html(i18n.getPropertyValue('loadingText'));

        for (var i = 0, f; f = files[i]; i++) {
            if (conversationView.canLoadFile(f)) {
                var reader = new FileReader();

                reader.onload = (function(theFile) {
                    return function(e) {
                       var img;
                       $('#selectedImage').attr('src', null);
                       $('#selectedImage').attr('width', null);
                       $('#selectedImage').attr('height', null);
                       $('#selectedImage').attr('style', null);
                       $('#photoPaneTextArea span').css('display', 'none');

                       $('#selectedImage').attr('title', escape(theFile.name));
                       $('#selectedImage').attr('src', e.target.result);

                       $('#selectedImage').bind('error', function() {
                            $('#photoPaneTextArea span').css('display', 'block');
                            $('#photoPaneTextArea span').html(i18n.getPropertyValue('errorLoad'));
                       });

                       img = document.getElementById('selectedImage');
                       img.onload = function() {
                           setTimeout(function(){
                                var fpos,
                            	pictureFrameWidth;

                                conversationView.calculateImagePreview();
                                $('#pictureContainer').animate({'opacity': '1'}, 400);
                                fpos = App.pictureManagement.finalLeftPosition;
                                $('#pictureFrame').animate({'left': fpos }, 300, function() {
                                    $('#btnCloseImg').css('opacity', '1');
                                });
                                pictureFrameWidth = $('#pictureFrame').width();
                                $('#photoCaption').css('width', 335 - pictureFrameWidth);
                                conversationView.enableChatButton();
                           }, 500);
                        };
                    };
                })(f);

                //Read in the image file as a data URL.
                reader.readAsDataURL(f);
            } else {
                $('#photoPaneTextArea span').css('display', 'block');
                if (f.size === 0){
                    $('#photoPaneTextArea span').html(i18n.getPropertyValue('errorEmptyImage'));
                }else{
                    $('#photoPaneTextArea span').html(i18n.getPropertyValue('errorLoad') + '; ' + f.type);
                }
            }
        }
    },

    canLoadFile: function(f) {
        var canLoad = false;

        if (f.type.match('image/jpeg') ||
            f.type.match('image/pjpeg') ||
            f.type.match('image/gif') ||
            f.type.match('image/jpg') ||
            f.type.match('image/png')) {
                canLoad = true;
        }

        return canLoad;
    },

    calculateImagePreview: function() {
        var img = document.getElementById('selectedImage');
        var w = img.offsetWidth;
        var h = img.offsetHeight;
        var contHeight = 0;
        var contWidth = 0;
        var scaledImgTop = 0;
        var scaledImgLeft = 0;
        var scaledImgWidth = 0;

        contHeight = 90;
        contWidth = 90;
       
        if( w > h) {
                scaledImgTop = 0;
                scaledImgLeft = (90-(90*w/h))/2;
                scaledImgWidth = 90*w/h;
                scaledImgHeight = 90; 
        } else {
                scaledImgTop = (90-(90*h/w))/2;
                scaledImgLeft = 0;
                scaledImgWidth = 90;
                scaledImgHeight = 90*h/w;
        }

        App.pictureManagement.initialLeftPosition = 0;
        App.pictureManagement.finalLeftPosition = 360 - contWidth;

        $('#pictureFrame').css('height', contHeight);
        $('#pictureFrame').css('width', contWidth);
        $('#pictureFrame').css('left', App.pictureManagement.initialLeftPosition);
        $('#selectedImage').css('width', scaledImgWidth);
        $('#selectedImage').css('height', scaledImgHeight);
        $('#selectedImage').css('top', scaledImgTop);
        $('#selectedImage').css('left', scaledImgLeft);
    },

    deletePhoto: function() {
        this.disableChatButton();
        $('#photoCaption').css('width', 352);

        $('#pictureContainer').animate({
            'opacity': '0'
        },200, function() {
             conversationView.$el.find('.input-holder').removeClass('imageSelected');
        });

        $('#pictureContainer #btnCloseImg').animate({
            'opacity': '0'
        }, 200);
    },

    generateThumbnail: function(objImg) {
        var pictureOrientation;
        var thum_w, thum_h;
        var scaledImgLeft,scaledImgTop,scaledImgWidth,scaledImgHeight;
        var w = objImg.prop('width');
        var h = objImg.prop('height');
        var lat = 90; 

        if( w > h) {
                scaledImgTop = 0;
                scaledImgLeft = (lat-(lat*w/h))/2;
                scaledImgWidth = lat*w/h;
                scaledImgHeight = lat;

        } else {
                scaledImgTop = (lat-(lat*h/w))/2;
                scaledImgLeft = 0;
                scaledImgWidth = lat;
                scaledImgHeight = lat*h/w;
        }

        var c = document.createElement('canvas');
        c.width = lat;
        c.height = lat;

        var ctx=c.getContext("2d");
        var img= document.getElementById('selectedImage');
        ctx.drawImage(img,scaledImgLeft,scaledImgTop,scaledImgWidth,scaledImgHeight);

        return {"imgData":c.toDataURL("image/jpeg"),"imgWidth":c.width,"imgHeight":c.height};
    },

    showPicture: function(num) {
        var pictureID = "back-to-the-future-1.jpg";
        window.pictureViewer = new App.PictureView(pictureID);
    },
    getCurrentThumbnail: function() {
        return this.$el.find('#pictureContainer img');
    },

    showLocationBox: function() {
    	$('#advancedMap').hide();
    	$('#locationMap, #locationSearchBox').show();
    	conversationView.disableChatButton()
    	
    	$('#locationSearchBox').html('<span>' + i18n.getPropertyValue('searchLocation') + '</span>');
    	
        this.$el.find('.input-holder').removeClass().addClass('input-holder').addClass('location');
        this.eventType = EventType.location;
        $('#locationMap').html('<span>' + i18n.getPropertyValue('loadingText') + '</span>');
        Yarn.Geo.drawMap('#locationMap');
        
        Yarn.Geo.getCurrentAddress();
    },
    
    searchRecommendation: function() {    	
    	if (Yarn.Geo.map != null){    		
    		$('#locationMap').hide();
        	$('#advancedMap').html('');

    		for (i = 0; i < Yarn.Geo.map.length; i++) {
				var mapWithRecommendation = Yarn.Geo.map[i];
				var template = _.template($('#tmpl_foursquare_list').html(), mapWithRecommendation);
				$('#advancedMap').append(template);             
    		}

	    	$('#advancedMap').css('display', 'block');
	    	$('#advancedMap').scrollTop('0');
    	}
    },

    selectedItemFoursquare: function(namePlace, address, lat, lng) {
        var geocoder = new google.maps.Geocoder();
    	
        if (!address){
        	var latLng = new google.maps.LatLng(lat, lng);
        	geocoder.geocode({'latLng': latLng}, function(results, status) {
        		if (status == google.maps.GeocoderStatus.OK) {
        			Yarn.Geo.currentAddress = results[0].formatted_address;
        			Yarn.Geo.namePlace = namePlace;
        			conversationView.refreshAddressBox(namePlace, Yarn.Geo.currentAddress);
        			conversationView.enableChatButton();
        		} 
        	});
        }else {
        	geocoder.geocode({'address': address}, function(results, status) {
        		if (status == google.maps.GeocoderStatus.OK) {
        			Yarn.Geo.currentAddress = results[0].formatted_address;
        			Yarn.Geo.namePlace = namePlace;
        			conversationView.refreshAddressBox(namePlace, Yarn.Geo.currentAddress);
        			conversationView.enableChatButton();
        		} 
        	});
        }
    },

    setSpace: function(eventType) {
        var h;
        if(eventType == EventType.image) {
            var pictureHeight, message, textHeight;
            message = $('#chatpane ul.conversation li').last();
            textHeight = message.find('#text').height() + 16;
            pictureHeight = message.find('#photo').height();

            if (pictureHeight > textHeight) {
               h = 12 + pictureHeight/2 - textHeight/2;
               message.find('#contw').css('top', h-5);
               message.find('#photo').css('top', -h);
               message.find('#msg-load').css('top', h);
            }else{
               h = 20;
               message.find('#contw').css('top', h);
               message.find('#photo').css('top', -h);
               message.find('#contw').css('padding-bottom', h);
            }
        }
    },

    resendChat: function(event) {
        var cid = $(event.currentTarget.parentElement).attr('id');
        var item = conversationView.model.getByCid(cid);

        // Save current eventType to set it another time after resend the current message
        var currentEventType = this.eventType;
        event.preventDefault();

        //TODO change icon -> loading .gif

        //remove from localStorage
        Storage.deleteConversationItem(conversationView.msisdn, cid);

        //remove from pane
        $(event.currentTarget.parentElement).hide('fast', function() {
            $(event.currentTarget.parentElement).remove();

             //resend chant
            conversationView.eventType = item.eventType;
            this.eventType = item.eventType;

            if(item.eventType==EventType.text){
                $('#txt-input').val(item.body);
            }else if (item.eventType==EventType.location){

            	Yarn.Geo.currentAddress = item.address;
            	Yarn.Geo.currentLatitude = item.latitude;
            	Yarn.Geo.currentLongitude = item.longitude;

            }else if (item.eventType == EventType.image) {
                // Create imageMessage with data of the old element to resend it
                conversationView.image = new ImageMessage();
                conversationView.image.thumbnail = item.thumbnail;
                conversationView.image.width = item.width;
                conversationView.image.height = item.height;
                conversationView.image.caption = item.caption;
            }
            conversationView.sendChat();

            // set the currentEventType from previsouly saved one
            conversationView.eventType = currentEventType;
        });
    },

    /* NOTIFICATIONS BY SIP SERVER */
    /* Messages received by SIP Server*/
    receiveReply: function(msisdn, txtMessage) {
        var messageEvent;

        txtMessage = conversationView.deleteCharacterHTML(txtMessage);
        txtMessage = conversationView.linkify(txtMessage);

        messageEvent = new MessageEvent(EventType.text);
        messageEvent.setMessage(txtMessage);
        messageEvent.direction = DirectionType[1];

        conversationView.saveMessage(messageEvent, msisdn);
        if (msisdn == conversationView.msisdn) {
            conversationView.showMessageInPane(messageEvent);
            conversationView.animateChatAppearance();
        }

        App.inboxView.increaseMsgCount(msisdn);
    },

    receivePicture: function(msisdn, message){
        var xmlDoc = $.parseXML( message );
        var $xml = $( xmlDoc );

        var caption = $xml.find("caption" ).text();
        var thumbnail = $xml.find("thumbnail" ).text();
        var uri = $xml.find("uri" ).text();

        var src = 'data:image/jpeg;base64,'+thumbnail;
        var width, height;
        var messageEvent;

        var img = new Image();
        img.onload = function() {
            width = img.width ;
            height= img.height;
        };
        img.src=src;

        messageEvent = new ImageMessage();
        messageEvent.thumbnail = src;
        if(caption){
             messageEvent.caption = caption;
        }
        if(uri){
            messageEvent.uri = uri;
        }

        messageEvent.heigth=height;
        messageEvent.width = width;
        messageEvent.direction = DirectionType[1];

        conversationView.saveMessage(messageEvent, msisdn);

        if (msisdn == conversationView.msisdn) {
            conversationView.showMessageInPane(messageEvent);
            conversationView.animateChatAppearance();
        }

        conversationView.setSpace(messageEvent.eventType);

        App.inboxView.increaseMsgCount(msisdn);
    },
    receiveAudio: function(msisdn, message){
        var xmlDoc = $.parseXML( message );
        var $xml = $( xmlDoc );

        messageEvent = new  AudioMessage();
        messageEvent.duration =  $xml.find('duration').text();
        messageEvent.uri = $xml.find('uri').text();
        messageEvent.direction = DirectionType[1];

        conversationView.saveMessage(messageEvent, msisdn);

        if (msisdn == conversationView.msisdn) {
            conversationView.showMessageInPane(messageEvent);
            conversationView.animateChatAppearance();
        }

        App.inboxView.increaseMsgCount(msisdn);
    },
    receiveLocation: function(msisdn, message){
        var xmlDoc = $.parseXML( message );
        var $xml = $( xmlDoc );

        var address = $xml.find( "address" ).text();
        var coordinates = $xml.find( "coordinates" ).text();
        var array = coordinates.split(" ");
        var latitude = array[0];
        var longitude = array[1];

        var messageEvent = new LocationMessage();
        messageEvent.latitude = latitude;
        messageEvent.longitude = longitude;
        messageEvent.address = address;
        messageEvent.direction = DirectionType[1];

        conversationView.saveMessage(messageEvent, msisdn);

        if (msisdn == conversationView.msisdn) {
            conversationView.showMessageInPane(messageEvent);
            conversationView.animateChatAppearance();
        }

        App.inboxView.increaseMsgCount(msisdn);
    },

    /* Status sent from server */
    receiveStatusSent: function(msisdn, opaque, commId){
        conversationView.changeStatus(msisdn, MessageStatus.sending, MessageStatus.sent, opaque, commId);
    },

    receiveStatusError: function(msisdn, opaque){
        conversationView.changeStatus(msisdn, MessageStatus.sending, MessageStatus.error, opaque, '');
    },

    receiveStatusReceived : function(msisdn, commId){
        conversationView.changeStatus(msisdn, MessageStatus.sent, MessageStatus.received, '',commId);
    },

    changeStatus: function(msisdn, lastStatus, newStatus, opaque, commId){
        var messagesList = Storage.getUserConversation(msisdn);
        if (messagesList) {
            var i = messagesList.length -1;

            //If the new state is 'error', we have to search by opaque
            //If the new state is 'sent' , we have to search by opaque and update 'comm-id' attribute
            //if the new state is 'received, we have to search by commId
            var searchCondition = false;
            var found =false;

            while (!found && i>=0){
                if(newStatus==MessageStatus.error || newStatus==MessageStatus.sent){
                    searchCondition = messagesList[i].cid==opaque;
                } else if (newStatus==MessageStatus.received){
                    searchCondition = messagesList[i].commId==commId;
                }

                found =messagesList[i].status == lastStatus && searchCondition;

                if(!found){
                    i--;
                }
            }

            if(found){
                messagesList[i].status = newStatus;
                if(newStatus==MessageStatus.sent){
                    messagesList[i].commId = commId;
                }

                Storage.replaceConversationMessage(msisdn, messagesList[i], i);

                //refresh the message in pane
                if (msisdn == conversationView.msisdn) {
                    conversationView.replaceMessageInPane(messagesList[i]);

                    // Set space after doing replace of a message due to status change
                    conversationView.setSpace(messagesList[i].eventType);
                }
            }
        }
    },

    /* Draw a message using underscore template for messages*/
    replaceMessageInPane : function(jsonMessage) {
        var currentElement = this.$el.find('#chatpane ul.conversation li#'+jsonMessage.cid);
        var previousElement = currentElement.prev();
        var template;
        currentElement.remove();

        switch (jsonMessage.eventType) {

            case EventType.text:
                template = _.template($('#tmpl_mesage_text').html(), jsonMessage); //window.myAppRouter.getTemplateText(jsonMessage);
                break;

            case EventType.image:
                template = _.template($('#tmpl_mesage_text_and_picture').html(), jsonMessage); //window.myAppRouter.getTemplatePicture(jsonMessage);
                break;

            case EventType.location:
                template = _.template($('#tmpl_mesage_location').html(), jsonMessage);
                break;

            case EventType.audio:
                template = _.template($('#tmpl_message_audio').html(), jsonMessage);
                break;
        }

        if(previousElement.html()) {
            previousElement.after(template);
            previousElement.next().addClass('before');
        }else{
             this.$el.find('#chatpane ul.conversation').append(template);
             this.$el.find('#chatpane ul.conversation li').last().addClass('before');
        }

        if(jsonMessage.eventType==EventType.location){
        	Yarn.Geo.showLocationAsImageMessage('.id'+jsonMessage.timeReceived, jsonMessage.latitude, jsonMessage.longitude);
        }
    },

    showAudioBox: function(event){
        this.$el.find('.input-holder').removeClass().addClass('input-holder').addClass('audio');
        this.eventType = EventType.audio;
        AudioController.stop();
    },

    openAudioFileBrowser: function(){
        $('#audioFileBrowser').click();
    },


    handleAudio: function(ev){
        var file,
            files;

        ev.preventDefault();
        conversationView.$el.find('.input-holder').addClass('audioSelected');

        file = window.URL.createObjectURL(ev.currentTarget.files[0]);
        document.getElementById('audioPlayer').src = file;

        AudioController.setAudio($('#audioPlayer')[0]);
        setTimeout(AudioController.setTotalDuration, 500);

        files = ev.target.files;
        for (var i = 0, f; f = files[i]; i++) {
            var reader = new FileReader();
            reader.onload = (function(theFile) {
                return function(e) {
                   AudioController.setAudioData(e.target.result);
                   conversationView.enableChatButton();
                };
            })(f);

            //Read in the image file as a data URL.
            reader.readAsDataURL(f);
        }

        this.error = function() {
            console.log('An error occurred while reading the file.');
            console.log(this.reader.error);
        };
    },

    playAudio: function(e){
        e.preventDefault();
        AudioController.playPauseClick();
    },

    reRecord: function(e){
        e.preventDefault();
        $('#audioFileBrowser').val('');
        conversationView.showAudioBox(e);
    },

    playPauseMessageAudio: function (ev){
        if($(ev.currentTarget).hasClass('on')){
            $(ev.currentTarget).removeClass('on');
        }else{
            $('.audioMessageButton').removeClass('on');
            $(ev.currentTarget).addClass('on');
        }

        MessageAudioController.setAudio($(ev.currentTarget.parentElement.parentElement).attr('id'), 'remotePath' );
        setTimeout(MessageAudioController.setTotalDuration, 500);
    },

    /**
     * Clean the input field before selecting a new image
     * Because chrome doesn't detect a change if you select
     * the same image we need to clean the input before
     * @param  evt  click event on #inputFile
     */
    cleanImageInput: function(evt){
        $(evt.target).val('');
    }
});

