var Register = Register || {};

Register.RegisterView = Backbone.View.extend({
	msisdn: null,
    validationCode: null,
    regionPhone: 'es',
    el: 'body', 
    events: {
        'click #buttonGo': 'registerMobilePhone',
        'click #btnNextValidate': 'goToValidatePage',
    },
    initialize: function() {
        TID.log.debug("-> initialize");
        this.render();
    },
    render: function() {
        TID.log.debug("-> REGISTER:-> render");
    },   
    registerMobilePhone: function() {
        TID.log.debug("-> registerMobilePhone");
        this.showPinInputBox();
    },
    showPinInputBox: function() {
        TID.log.debug("-> showPinInputBox");
        this.registerConfirmation();
    },
    registerConfirmation: function() {
        //only if valid number is provided and the check is checked
        this.msisdn = this.$el.find('#inputMobile').val();
        
        if (this.validatePhoneNumber(this.msisdn)) {
        	this.registerMsisdn();
        } 
    },

    validatePhoneNumber: function(phoneNumber){
    	var validatePhone = true;

    	var phoneUtil = i18n.phonenumbers.PhoneNumberUtil.getInstance();
    	var number = phoneUtil.parseAndKeepRawInput(phoneNumber, this.regionPhone);

    	if (validatePhone){
    		validatePhone = phoneUtil.isPossibleNumber(number);
    	}

    	if (validatePhone){
    		validatePhone = phoneUtil.isValidNumber(number);
    	}

    	if (validatePhone){
    		var PNT = i18n.phonenumbers.PhoneNumberType;

    		validatePhone = phoneUtil.getNumberType(number) == PNT.MOBILE;
    	}

    	if (validatePhone){
    		validatePhone = phoneUtil.isValidNumberForRegion(number, this.regionPhone);
    	}

    	if (!validatePhone) {
    		alert(i18n.getPropertyValue('errorInvalidPhoneNumber'));
    	}
    	
    	return validatePhone;
    },

    goToValidatePage: function(){
    	 var code = this.$el.find('#inputPIN').val();
    	 this.validationCode = code;
        
         if(code.length == 4) {
        	 ApiClient.validateUser(this.msisdn, code, '', this.validateResponse, this.validateErrorCode);
         }
         else{
        	 this.validateErrorCode();
         }
    }, 

    /**
    * Gets the msisdn and call API register method
    */
	registerMsisdn: function() {
		ApiClient.registerUser(this.msisdn, this.regionPhone, this.registerResponse, this.registerErrorCode);
    },

    registerResponse: function(response) {
        this.$('#buttonGo').addClass('hidden');
        this.$('#inputPIN').val('');
        this.$('#pinGroup').removeClass('hidden');
        this.$('#btnNextValidate').removeClass('hidden');
    },

    registerErrorCode: function() {
        alert(i18n.getPropertyValue('errorRegister'));
    },
    
    validateErrorCode: function(response) {
    	alert(i18n.getPropertyValue('errorInvalidCode'));
    },

    validateResponse:function(response) {
        var user = response.user;
        var msisdn = user.msisdn;
        var password = user.password;
        var userId = user.user_id;

        $.cookie('username', ApiClient.msisdn);
        $.cookie('password', ApiClient.password);
        $.cookie('userId', ApiClient.userId);

		 window.location = 'index.html';
    },

    showContactsPagePermission: function() {
        TID.log.debug('fin. Mostrar aviso de contactos');
        $('#btnDone').addClass('active');
        $('.spinner').css('display', 'none');
    },

});

$(document).ready(function() {
    Register.registerView = new Register.RegisterView();   
});

