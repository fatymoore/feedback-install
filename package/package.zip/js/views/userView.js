App.UserView  = Backbone.View.extend( {
    tagName: 'li',
    className: 'contact',
    events: {
        'click .contact-handler': 'clickUser',
        'click  #msg-trash': 'deleteConversation',
    },
    initialize : function() {
        this.template = _.template($('#tmpl_user').html()); //, data
        _.bindAll(this, 'render');
        this.model.bind( 'change', this.render );
    },

    getUserPicture : function () {
        var userPhoto = this.model.get('pictureFile');
        if( userPhoto === null ) {
            var m = this.$el.find('.contact-img');
            return "generic_user_1.jpg";
        } else{
            return userPhoto;
        }
    },
    loadConversation: function() {
        var userName = this.model.get('name') + "&nbsp;" + this.model.get('surname');
        var userPicture = this.getUserPicture();
        var userMobile = this.model.get('msisdn');
        //myAppRouter.navigate('conversation/'+ userName +'/'+ userMobile,true);
        myAppRouter.navigate( 'conversation/' + userName + '/' + userMobile + '/' + userPicture, true );
    },
    unselectUser: function() {
        if (App.inboxView.collection.selectedUserModel != null){
            var lastSelectedUser = App.inboxView.collection.selectedUserModel;
            var m = $(lastSelectedUser).find('.contact-handler');
            this.collection.selectedUserEl.removeClass('selected');
        }
    },
    markAsSelected: function(){
        App.inboxView.collection.selectedUserModel = this.model;
        this.collection.selectedUserEl = $(this.el).find('.contact-handler');
    },
    clickUser: function() {
        this.loadConversation();
        this.unselectUser();
        this.markAsSelected();
        this.selectUser();
    },
    selectUser: function() {
        var m = this.$el.find('.contact-handler');
        m.addClass('selected');
        this.model.set('unreadMessages',0,{silent: true});
        this.updateUnreadIndicator();
    },

    render : function () {
        TID.log.debug("render UserView");
        //var renderedContent = this.template;
        var renderedContent = this.template( this.model.toJSON() );
        $(this.el).html( renderedContent );
        this.updateUnreadIndicator();
        this.setUserStatus();
        this.selectIfNecessary();
        return this;
    },

    setUserStatus: function () {
        TID.log.debug("setStatus UserView");
        var m = this.$el.find('.contactStatus');
        var s = this.model.get('presence');
        switch ( s ) {
            case 0:
                m.addClass('offline');
                break;
            case 1:
                m.addClass('online');
                break;
        }
    },

    updateUnreadIndicator: function () {
        TID.log.debug("updateUnreadIndicator UserView");
        var num = this.model.get('unreadMessages');
        var htm = this.$el.find('.unreadMessages');

        if ( num > 0 ) {
            if ( ! htm.hasClass('updatedInBackground') ) {
                htm.addClass('updatedInBackground');
            }
        } else {
            htm.removeClass('updatedInBackground');
        }
    },

    selectIfNecessary: function () {
        TID.log.debug("selectIfNecessary UserView");
        try {
            if ( App.inboxView.collection.selectedUserModel !== null ) {
                msisdnTalkingUser = App.inboxView.collection.selectedUserModel.get('msisdn');
                msisdnRenderedUser = this.model.get('msisdn');
                if ( msisdnRenderedUser == msisdnTalkingUser) {
                    this.selectUser();
                    this.markAsSelected();
                }
            }
        } catch ( err ) { }
    },

    showDetails: function () {
        TID.log.debug("showDetails UserView");
        this.collection.trigger('select', this.model);
    },

    callContact: function () {
        TID.log.debug("callContact UserView");
    },

    editContact: function () {
        TID.log.debug("editContact UserView");
    },

    dragStartEvent: function ( e ) {
        TID.log.debug("dragStartEvent UserView");
    },

    deleteConversation: function(event){
    	var myMsisdn = $.cookie('username');
    	var cid = App.inboxView.collection.selectedUserModel.get('msisdn');
    	ApiClient.deleteConversation(myMsisdn, cid, this, this.deleteResponseConversation, this.deleteErrorCodeConversation);
    },

    deleteResponseConversation: function( cid, msisdn, clientWeb ) {
    	$('#' + cid).remove();
        /*Borrar del localStorage*/    	
    	Storage.deleteConversation(msisdn, cid);

    	window.location.reload ();
    },

    deleteErrorCodeConversation: function(response) {
    	alert(i18n.getPropertyValue(response));
    },
});
