var MainView = Backbone.View.extend( {

    events: {
        'click #app-head-logo': 'appheadlogo',
        'click #btnBack': 'backButton',
        'click #iconAddContact': 'addContact'
    },

    initialize: function () {
        //TID.log.debug("---> Main layout view, initialize function.");
        App.Layout.recalculate();
        window.userMenu = new App.UserMenuView();
        this.loadTemplates();
        this.createButtonEvents();
        this.usersScreenName = $.cookie('username');
    },

    createRouter: function () {
        window.myAppRouter  = new AppRouter();
        Backbone.history.start();

        Api.init( $.cookie('username') );
        Api.authorization("", "", function () {
            App.inboxView = new App.InboxView();
            window.myAppRouter.navigate("inboxScreen",true);
        });

        this.showStatus( Yarn.PresenceStatus.Connecting );
        this.openSIPConnection();
    },

    render: function () {
        TID.log.debug("-> AppView -> render");
    },

    openSIPConnection: function () {
      var user= $.cookie('username');
      var password =$.cookie('password');

      if ( user && password ) {
        mainView.showStatus( Yarn.PresenceStatus.Connecting );
        RtcManager.register( user, password );
      } /*else{
        window.myAppRouter.gotoLoginPage();
      }*/
    },

    appheadlogo: function () {
        TID.log.debug("-> AppView -> Click over main logo");
        window.myAppRouter.navigate("landingScreen",true);
    },

    loadTemplates: function () {
        TID.log.debug("-> AppView -> load templates");

        var tplContainer = $('#templates');

        $.each( Yarn.Constants.templates, function ( i, item ) {
            $.ajax( { async:false,
                type: 'GET',
                url:item.html,
                dataType: "html",
                success: function ( data ) {
                    $('#templates').append( data );
                },
                error: function (xhr, textStatus, errorThrown ) {
                    // Look at the `textStatus` and/or `errorThrown` properties.
                    TID.log.error("Error ocurred while attempting to get template: " + item.html);
                    TID.log.error(xhr);
                }
            });
        });
    },

    createButtonEvents: function () {

        $('#btnTimeOrder').click( function () {
            $('#btnTimeOrder').addClass("selected");
            $('#btnAlphabeticalOrder').removeClass("selected");
            $('#btnStatusOrder').removeClass("selected");
            App.inboxView.sortUsers(1);
        });

        $('#btnAlphabeticalOrder').click( function () {
            $('#btnTimeOrder').removeClass("selected");
            $('#btnAlphabeticalOrder').addClass("selected");
            $('#btnStatusOrder').removeClass("selected");
            App.inboxView.sortUsers(2);
        });

        $('#btnStatusOrder').click( function () {
            $('#btnTimeOrder').removeClass("selected");
            $('#btnAlphabeticalOrder').removeClass("selected");
            $('#btnStatusOrder').addClass("selected");
            App.inboxView.sortUsers(3);
        });

        $('#btnKeyPad').click( function () {
            $('#btnKeyPad').addClass("selected");
        });

        $('#btnGroup').click( function () {
            $('#btnGroup').addClass("selected");
        });

        $('#btnBroadcast').click( function () {
            $('#btnBroadcast').addClass("selected");
        });

        $('#btnAddContact').click( function () {
            window.myAppRouter.navigate('addContact',true);
        });

        $('#btnCancelAddContact').click( function () {
            window.myAppRouter.navigate('closeAddContact',true);
        });

        $('#btnAddContactDone').click( function () {
            window.myAppRouter.navigate('closeAddContact',true);
        });

        // SETTINGS
        $('#btnSettingsClose').click(function() {
            window.App.Layout.hideSettingsPanel();
            console.log("close settings window");
        });

        $('#btnSettingsBack').click(function() {
            window.myAppRouter.backSettingsPanel();
            console.log("back settings window");
        });

    },

    showStatus: function ( status ) {
          // update RtcManager.status
        RtcManager.status = status;

        if( status == Yarn.PresenceStatus.Online ) {
          $('#user-status').removeClass().addClass('online');
          mainView.updateScreenName(mainView.usersScreenName);
        } else if (status == Yarn.PresenceStatus.Offline ) {
          $('#user-status').removeClass().addClass('offline');
          mainView.updateScreenName(mainView.usersScreenName);
        } else if ( status == Yarn.PresenceStatus.Idle ) {
          $('#user-status').removeClass().addClass('iddle');
          mainView.updateScreenName(mainView.usersScreenName);
        } else if ( status == Yarn.PresenceStatus.Busy ) {
          $('#user-status').removeClass().addClass('busy');
          mainView.updateScreenName(mainView.usersScreenName);
        } else if ( status == Yarn.PresenceStatus.Connecting ) {
          $('#user-status').removeClass().addClass('offline');
          mainView.updateScreenName(i18n.getPropertyValue('statusConnecting'));
        }
    },

    updateScreenName: function ( newScreenName ) {
        $('#username').html(newScreenName);
    },

    backButton: function () {
        myAppRouter.navigate('backToInbox', true);
    },

    addContact: function () {
        App.inboxView.addContactsFromAddressBook();
    }

} );

/**
 * Creates de main view in Backbone.
 */

var initMainPage = function () {
  mainView = new MainView({
    el : $("body") //para que las búsquedas se puedan hacer desde aquí.
  });
  document.mainview = mainView;
};
