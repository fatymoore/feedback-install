var landingView,
    LandingView = Backbone.View.extend( {

        tplContainer  : Yarn.Constants.templates.landing.idContainer,
        templateName : Yarn.Constants.templates.landing.name,

        initialize : function () {
            //TID.log.debug("initialize LandingView");
            $('#mainRightPanel').load('templates/moduleLandingPage.html', window.App.Layout .recalculate);
            this.getUserDataUser();
            this.model = new LandingModel();
        },
        events : {/* Aquí se ponen los eventos de los elementos de la página */
            //"click button" : "checkUser"
        },
        //event's functions
        getUserDataUser : function ( event ) {
            //With username and password stored in the cookie,
            //we have to get the user's screen name to show in the top right menu
        },

        /*
         * This function goes to server (or MOCK) and get user's contacts.
         * So we have to parse it and store them in our model
         *
         */
        getData : function ( msisdn ) {

            $.when(
                landingView.getRecentUsers( msisdn ),
                landingView.getNewUsers( msisdn ),
                landingView.getSuggestedPeople( msisdn )

            ).done( function ( esta ) {
                landingView.render();
            } );


        },

        getRecentUsers : function ( msisdn ) {
            var contacts = Api.getRecentUsers( msisdn ),
                json,
                browser = $.browser;

            if ( ( browser != 'msie' ) || ( browser != 'mozilla' ) ) {
                json = $.parseJSON( contacts );
            } else {
                json = contacts;
            }

            $.each ( json.contactsVIP, function ( key, item ) {
                var msisdn2 = item.msisdn,
                    user = Api.getUserInfo( msisdn2 );
                landingView.model.recentUsers.push( user );
            });

        },

        getNewUsers : function ( msisdn ) {
            var contacts = Api.getNewUsers( msisdn ),
                json,
                browser = $.browser;

            if ( ( browser != 'msie' ) || ( browser != 'mozilla' ) ) {
                json = $.parseJSON( contacts );
            } else {
                json = contacts;
            }

            $.each( json.newContacts, function ( key, item ) {
                var msisdn2 = item.msisdn ;
                var user = Api.getUserInfo( msisdn2 );
                landingView.model.newUsers.push( user );
            });

        },

        getSuggestedPeople : function ( msisdn ) {

        },

        /*
         * Once we have the user's contact in our model, we should paint them
         * in our template
         */
        render : function () {
            $("#"+this.tplContainer).html('');
            var template = _.template( $("#" +this.templateName).html(), this.model );

            // Load the compiled HTML into the Backbone "el"
            this.$el.find("#"+this.tplContainer).append( template );

        }
    });

/**
 * Creates de contact view in Backbone.
 */
var initLandingPage = function () {
    landingView = new LandingView ( {
        el : $("#mainRightPanel") //para que las búsquedas se puedan hacer desde aquí.
    } );
    document.landingview = landingView;
};
