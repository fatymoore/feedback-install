var StorageManager = {

    sendAudio: function ( audioFile, callback ) {
        var serverUrl = SANDBOX_STORAGE;

        TID.log.debug( audioFile );

        $.ajax( {
            url: serverUrl,
            typ : "POST",
            beforeSend: function ( request ) {
                request.setRequestHeader("Authorization", Yarn.Constants.AUTH_BEARER + Api.token);
                request.setRequestHeader("Accept", 'audio/aac');
                request.setRequestHeader("Content-Type", 'audio/aac');

                TID.log.debug("Authorization: " + Yarn.Constants.AUTH_BEARER + Api.token);
                TID.log.debug("Accept", 'audio/aacg');
                TID.log.debug("Content-Type", 'audio/aac');
            },
            data: audioFile,
            success: function ( response ) {
                TID.log.debug('Storage OK, audio uploaded');
                TID.log.debug(response);

                if(callback){
                    callback();
                }
            },
            error: function( xhr, ajaxOptions, thrownError ) {
                TID.log.debug("error in Storage. Status: " + xhr.status + ". " + thrownError + ": " + thrownError);
            }
        });
    },

    sendPicture: function ( picture, callback ) {
        var serverUrl = SANDBOX_STORAGE;

        TID.log.debug(picture);

        $.ajax( {
            url: serverUrl,
            type: "POST",
            beforeSend: function (request){
                request.setRequestHeader("Authorization", Yarn.Constants.AUTH_BEARER + Api.token);
                request.setRequestHeader("Accept", 'image/jpeg');
                request.setRequestHeader("Content-Type", 'image/jpeg');

                TID.log.debug("Authorization: " + Yarn.Constants.AUTH_BEARER + Api.token);
                TID.log.debug("Accept", 'image/jpeg');
                TID.log.debug("Content-Type", 'image/jpeg');
            },
            data: picture,
            success: function( response ) {
                TID.log.debug('Storage OK, picture uploaded');
                TID.log.debug(response);

                if(callback){
                    callback();
                }
            },
            error: function( xhr, ajaxOptions, thrownError ) {
                TID.log.debug("error in Storage. Status: " + xhr.status + ". " + thrownError + ": " + thrownError);
            }
        });
    }
};
