OwdRouter = Backbone.Router.extend({

    routes: {
        'inboxScreen' : 'showInboxScreen',
        'conversation/:userName/:msisdn' : 'showConversation',
        'closeAddContact' : 'closeAddContact',
        'settings' : 'showSettings',
        'blank': 'showBlank',
        'backToInbox': 'backToInbox'
    },

    initialize: function () {
       TID.log.debug('---> Router initialize');
    },

    showInboxScreen: function () {
        var user = $.cookie('username'),
          password = $.cookie('password');

        if ( user && password ) {
            App.inboxView = new App.InboxView();
                var mainWrapper = document.getElementById('main-wrapper');
                if ( mainWrapper.dataset.position == 'left' ) {
                    mainWrapper.dataset.position='right';
                }
            } else {
                this.gotoLoginPage();
            }
    },

    gotoLoginPage: function () {
        window.location = "register-owd.html";
    },

    showConversation: function ( data,  msisdn ) {
        var userName = data;
        /**
         * puesto que en OWD las app no se cargan siempre (si nos quedamos en inbox, no se hace un refresh)
         * hay que ver si nos quedamos en algun momento sin conexion
         *
         *
         */

        this.slide();

        $('#conversation-page').load('templates/moduleConversationOwd.html',
            function () {
                App.Layout.recalculateOwd();
                document.getElementById('user-name').innerHTML = userName;
                initConversationPage(msisdn, 'conversation-page');
            }
        );

        if( RtcManager.status == Yarn.PresenceStatus.Offline ) {
            TID.log.debug("opening SIP connection...");
            mainView.openSIPConnection();
        }
    },

    backToInbox: function () {
        this.slide();
    },

    addContact: function () {
        TID.log.debug('---> Router GOTO: Add contact');

        $('#btnAddContact').addClass('selected');
        App.Layout .contactsPanelBottomSpace = $('#addContactPanel').height() + 55;
        var portalHeight = $(window).height();
        var alto = portalHeight - App.Layout .contactsPanelBottomSpace - 175;

        // hide contacts scroll
        $('#contactsPanel').css('overflow-y', 'hidden');
        $('#contactsLoadLayer').fadeIn(400);
        $('#contactsPanel').animate({
            height: alto
          }, 300, function () {
            // Animation complete.
            $('#addContactPanel').fadeIn(400);
        });
    },

    closeAddContact: function () {
        TID.log.debug('---> Router GOTO: Close add contact');

        App.Layout .contactsPanelBottomSpace = 55;
        var portalHeight = $(window).height();
        var alto = portalHeight - App.Layout .contactsPanelBottomSpace - 175;

        $('#addContactPanel').fadeOut(300, function() {
            // Animation complete.
            $('#contactsLoadLayer').fadeOut(300, function() {
                // Animation complete.
                $('#btnAddContact').removeClass('selected');
            });

            $('#contactsPanel').animate({
                height: alto
            }, 300, function() {
                // Animation complete.
                // show contacts scroll
                $('#contactsPanel').css('overflow-y', 'scroll');
            });
        });
    },

    showSettings: function () {
        $('#mainRightPanel').load('templates/moduleSettings.html', window.App.Layout .recalculate);
        TID.log.debug('---> Router GOTO: settings');
    },

    showBlank: function () {
        TID.log.debug('---> Router GOTO: blank');
    },

    defaultRoute: function ( other ) {
        TID.log.debug('Invalid. You attempted to reach:' + other);
    },

    slide: function ( callback ) {
        var mainWrapper = document.getElementById('main-wrapper'),
            trEndCount = 0;

        mainWrapper.classList.add('peek');
        mainWrapper.dataset.position = ( mainWrapper.dataset.position == 'left' ) ? 'right' : 'left';
        mainWrapper.addEventListener('transitionend', function trWait() {
          trEndCount++;
          switch ( trEndCount ) {
            case 2:
              mainWrapper.classList.remove('peek');
              break;
            case 4:
              mainWrapper.removeEventListener('transitionend', trWait);
              if ( callback ) {
                callback();
              }
              break;
          }
        });
    },

    getTemplateContacts: function ( data ) {
        return getUserTemplate(data);
    },

    getTemplateText: function ( messageData ) {
        return getTextMessageTemplate(messageData);
    },

    getTemplatePicture: function ( messageData ) {
        return getPictureMessageTemplate(messageData);
    }

});
