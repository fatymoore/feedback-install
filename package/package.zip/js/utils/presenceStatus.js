var Yarn = Yarn || {};

Yarn.PresenceStatus = {
	Offline: "desconectado",
	Online: "1",
	Idle: "2",
	Busy: "3",
	Connecting: "4"
};