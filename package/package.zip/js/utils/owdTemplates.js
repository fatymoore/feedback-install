function getUserTemplate ( user ) {

   var template = [
      '<div class="contact-block">',
      ' <div class="contact-handler">',
      '     <div class="contact-img">',
      '         <div class="contactStatus"></div>',
      '     </div>',
      '     <div class="contact-link">',
      '         <div class="contact-info-container">',
      '             <div>',
      '                 <div class="contact-name hasCatchphrase">' + user.name + ' ' + user.surname + '</div>',
      '             </div>',
      '             <div class="contact-title">' + user.msisdn + ' ' + user.lastEvent + '</div>',
      '         </div>',
      '         <div class="unreadMessages">' + user.unreadMessages + '</div>',
      '         <div class="unreadCalls">' + user.unreadCalls + '</div>',
      '     </div>',
      ' </div>',
      '</div>'
    ].join('\n');

   return template;
}

function getTextMessageTemplate ( messageEvent ) {

    var emisor = messageEvent.direction == DirectionType[ 0 ] ? 'me': 'them';
    var date  = getMessageDate( messageEvent.timeReceived );

    var errorClass = '';
    if( messageEvent.status == MessageStatus.error ) {
        errorClass = 'msgError';
    }

    //status is only showed if we send the message
    var messageStatus = '';
    if ( messageEvent.emisor == 'me' ) {
        messageStatus = i18n.getPropertyValue('status')[ messageEvent.status ];
    }

    var starStyle = 'opacity: 0';
    if ( messageEvent.status == MessageStatus.sent || status == MessageStatus.received ) {
        starStyle = '';
    }

    var template = [
      '<li id="'+messageEvent.cid+'" class="'+emisor+' '+errorClass+'">'
    ].join( '\n' );


    if ( emisor == 'me' && messageEvent.status == MessageStatus.error ) {
         template += [
          '<div id="msg-load"></div>'
         ].join( '\n' );

     }


    template += [
      ' <div id="text" class="text" >'+messageEvent.body+'</div>',
      ' <div id="status" class="status">'+messageStatus+'</div> ',
      ' <div id="date" class="date">'+date+'</div> ',
      ' <div id="action" class="action">',
      '     <div id="msg-star" style="'+starStyle+'"></div>',
      '     <div id="msg-trash"></div>',
      ' </div>',
      '</li>'
    ].join('\n');

    return template;
}


function getPictureMessageTemplate ( messageEvent ) {


    var tex = messageEvent.caption;
    var img = messageEvent.thumbnail;
    var w = messageEvent.width;
    var h = messageEvent.height;
    var to = messageEvent.direction;
    var emisor = to == DirectionType[ 0 ] ? 'me': 'them';
    var date = getMessageDate( messageEvent.timeReceived );
    var pictureOrientation, pictureAdjustment;
    var photo_w, photo_h;
    var scaledImgTop, scaledImgLeft;
    var fw, fh;

    var errorClass = '';
    if ( messageEvent.status == MessageStatus.error ) {
        errorClass = 'msgError';
    }

    //status is only showed if we send the message
    var messageStatus = '';
    if ( emisor == 'me' ) {
        messageStatus = i18n.getPropertyValue('status')[ messageEvent.status ];
    }

   // var template =' <li id="'+messageEvent.cid+'" class="'+emisor+' picture '+errorClass+'">';
    var template = [
      '<li id="'+messageEvent.cid+'" class="'+emisor+' picture '+errorClass+'">'
    ].join( '\n' );


    if ( emisor == 'me' && messageEvent.status == MessageStatus.error ) {
        //template+='        <div id="msg-load"></div> ';
         template += [
          '<div id="msg-load"></div>'
         ].join('\n');
     }

    if ( w > h) {
        pictureOrientation = "horizontal";
        if ( ( w / 3 * 2 ) > h ) {
            scaledImgTop = 0;
            scaledImgLeft = ( 120 - ( 80 * w / h ) ) / 2;
            pictureAdjustment = "heightAdjusted";

        } else {
            var proportion = w / h;
            fh = Math.sqrt( 9600 / proportion );
            fw = 9600 / fh;

            scaledImgTop = 0;
            scaledImgLeft = 0;
            scaledImgWidth = fw;
            scaledImgHeight = fh;
            pictureAdjustment = "complete";
        }

    } else {
        pictureOrientation = "vertical";
        if ( ( h / 3 * 2 ) > w ) {
            scaledImgTop = ( 120 - ( 80 * h / w ) ) / 2;
            scaledImgLeft = 0;
            pictureAdjustment = "widthAdjusted";
        } else {
            var proportion = w / h;
            fh = Math.sqrt( 9600 / proportion );
            fw = 9600 / fh;

            scaledImgTop = 0;
            scaledImgLeft = 0;
            scaledImgWidth = fw;
            scaledImgHeight = fh;
            pictureAdjustment = "complete";
        }
    }

    photo_w = fw;
    photo_h = fh;
    var text_max_width = 360 - photo_w - 30;
    var date_max_width = 235 - photo_w - 30;
    var message_top = 0;
    var photo_top = 0;

    template += [
      ' <div id="contw" style="position:relative; top:'+message_top+'px;">',
      '     <div id="text" class="text"> ',
      '         <div id="photo" class="photo '+pictureOrientation+'" style="width:'+photo_w+'px; height:'+photo_h+'px; overflow: hidden; top:'+photo_top+'px;" onclick="console.log('+messageEvent.uri+')">',
      '             <img src="'+img+'" class="'+pictureAdjustment+'" style="top:'+scaledImgTop+'px; left:'+scaledImgLeft+'px;" onclick="conversationView.showPicture(000001)"/>',
      '         </div>',
      '         <div class="message-text" style="max-width: '+text_max_width+'px">'+tex+'</div>',
      '     </div>',
      '     <div id="status" class="status">' + messageStatus + '</div>'
    ].join( '\n' );

    if ( emisor == 'me' ) {
        template += '<div id="date" class="date" style="max-width: ' + date_max_width + 'px">' + date + '</div>';
    } else {
        template += '<div id="date" class="date">' + date + '</div>';
    }

    template += [
      ' <div id="action" class="action">',
      '     <div id="msg-star"></div>',
      '     <div id="msg-trash"></div>',
      ' </div>',
      '</div>',
      ' </li>'
    ].join( '\n' );

   /* template+='<div id="contw" style="position:relative; top:'+message_top+'px;">';
    template+=' <div id="text" class="text">';
    template+='    <div id="photo" class="photo '+pictureOrientation+'" style="width:'+photo_w+'px; height:'+photo_h+'px; overflow: hidden; top:'+photo_top+'px;" onclick="console.log('+messageEvent.uri+')">';
    template+='        <img src="'+img+'" class="'+pictureAdjustment+'" style="top:'+scaledImgTop+'px; left:'+scaledImgLeft+'px;" onclick="conversationView.showPicture(000001)"/>';
    template+='    </div>';
    template+='     <div class="message-text" style="max-width: '+text_max_width+'px">'+tex+'</div>';
    template+='</div>';
    template+='<div id="status" class="status">'+messageStatus+'</div> ';
    if(emisor=='me'){
        template+='<div id="date" class="date" style="max-width: '+date_max_width+'px">'+date+'</div>';
    } else{
        template+='<div id="date" class="date">'+date+'</div>';
    }
    template+='<div id="action" class="action">';
    template+='    <div id="msg-star"></div> ';
    template+='    <div id="msg-trash"></div> ';
    template+='</div>';
    template+=' </div>';
    template+=' </li>'; */

    return template;
}
