App.pictureManagement = {
    initialLeftPosition: 150,
    finalLeftPosition: 0 
}
