function getCurrentUTCTime() {
	var now = new Date(); 
	return Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(),  now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds(), now.getUTCMilliseconds()); 
}

function convertUtcToDate(utcDate) {
	return new Date(utcDate); 
}

function getMessageDate(utcDate) {
	
	var date = convertUtcToDate(utcDate); 
	var hour = date.toString(); 
	
	if(hour){
		hour = hour.substring(hour.indexOf(':')-2, hour.lastIndexOf(':')); 
	}
	
	var day = ''; 
	var now = new Date(); 
	//hoy
	if(now.getDate()==date.getDate() && now.getMonth()==date.getMonth() && now.getFullYear()==date.getFullYear()){
		day= recentTimes[0]; 
	}//ayer
	else if(now.getDate()==date.getDate()+1 && now.getMonth()==date.getMonth() && now.getFullYear()==date.getFullYear()){
		day= recentTimes[1]; 
	}else{
		day = getFullDate(date); 
	}
		
	return day + ' ' + hour; 
	
};

function getFullDate(date){
	
	var day = days[date.getDay()]; 
	var num = date.getDate(); 
	var month = months[date.getMonth()]; 
	var year = date.getFullYear().toString().substring(2);
	
	//return day + '  ' + num + '  ' + month + '  ' +year 
	return num + '  ' + month 
}

var days = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb']; 
var months = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic']; 
var recentTimes = ['Hoy', 'Ayer']; 
