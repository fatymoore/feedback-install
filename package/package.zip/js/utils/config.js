var DEBUG = true; //change to 'false' to PRODUCTION environment
var MOCK = false; //change to 'false' for API Connection

var PROD_SERVICES = 'https://service.yarnapp.com'; //produccion
var DES_SERVICES = 'https://vcs-sb70.jajah.com';//'http://xmpp.reflections.tid.es/yarn-api'; Sandbox

var LOCAL_URL = 'http://yarn.dev/';
var API_URL = DEBUG ? DES_SERVICES : PROD_SERVICES;

/* Lo de los mocks o servicios reales también debería ir aquí*/
//var MOCK_URL = "http://xmpp.reflections.tid.es/mocks/"
var MOCK_URL = "http://yarn.dev/js/data/";
var Api = MOCK ?  MockClient : ApiClient;
//var SANDBOX_STORAGE = 'https://storage-sandbox.jajah.com/StorageManager/BlobStorage/';

var SANDBOX_STORAGE = 'https://STM-SB70.jajah.com/StorageManager/BlobStorage/';
//var SANDBOX_STORAGE = 'https://storage.yarnapp.com/StorageManager/BlobStorage?blobId=52dfe630-9335-4287-b17c-b7795c2571f'; //Produccion

// Warning!
if ( MOCK === true ) {
	console.warn( 'You are in MOCK\'s MODE. Remember to uncomment the "tmpContact = source;" (extractUniqueContacts.js) line in order to load the contacts!!');
}