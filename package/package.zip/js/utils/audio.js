
var AudioController = {
	audio : null, 
	audioData: null, 
	duration: null, 
}

AudioController.setAudio=function(audioTag){
	this.audio = audioTag; 	
	
	document.getElementById('duration').innerHTML = '';
	$('#seek').attr('value',0);
	this.audio.addEventListener("timeupdate", function() {
           AudioController.updateTime();
    }, false);
    
    $("#seek").unbind(); 
    $("#seek").bind("change", function() {
        AudioController.audio.currentTime = $(this).val();
        $("#seek").attr("max", AudioController.audio.duration);
    });
    
}

AudioController.setAudioData = function(data){
	this.audioData = data; 
}

AudioController.playPauseClick = function () {
	if (!AudioController.audio){
	 	return; 
	}
	
    if (AudioController.audio.paused ) {
		AudioController.audio.play();
		
		$('#playPause').html('Pause'); 
	} 
    else{
		AudioController.stop();	
		
    }

}
AudioController.stop = function(){
	if (!AudioController.audio){
	 	return; 
	}
	
	AudioController.audio.pause();	  
	$('#playPause').html('Listen');  
}

AudioController.setTotalDuration = function(){
	var duration = AudioController.audio.duration; 
	var sec = parseInt(duration % 60, 10);
	var min = parseInt((duration / 60) % 60, 10);
	if(min<10){
		min = '0'+min; //para que los minutos tengan siempre dos digitos
	}
	if(sec<10){
		sec = '0'+sec; //para que los minutos tengan siempre dos digitos
	};
	
	AudioController.duration =  min + ':' + sec;
	document.getElementById('duration').innerHTML = AudioController.duration;
	$('#seek').attr('max',duration);
}
AudioController.updateTime = function () {
	if(this.audio.paused){
		return;
	}
	
	var s = parseInt(this.audio.currentTime % 60, 10);
	var min = parseInt((this.audio.currentTime / 60) % 60, 10);
	if(min<10){
		min = '0'+min; //para que los minutos tengan siempre dos digitos
	};
	
	if(s<10){
		s = '0'+s; //para que los minutos tengan siempre dos digitos
	};
	
    document.getElementById('duration').innerHTML = min + ':' + s + '/'+AudioController.duration ;
	$('#seek').attr('value',this.audio.currentTime);
}



///////////////////////////

var MessageAudioController={
	audio : null, 
	duration: null, 
	lastRemotePath: null, 
	playing: false,
}
MessageAudioController.setAudio=function(messageId, remotePath){
	
	if(MessageAudioController.playing){
		MessageAudioController.stop(); 
	}else{
		//if(remotePath==MessageAudioController.lastRemotePath){
		
		//TODO voy y obtengo el audio
		//MessageAudioController.audio = audio; 
		 
		//hasta que no este lo del Storage, reproduzco el audio del input
		MessageAudioController.audio = AudioController.audio; 
		
		this.audio.addEventListener("timeupdate", function() {
	           MessageAudioController.updateTime(messageId);
	    }, false);
	   
	    $('#' +messageId + ' .audioSeek').unbind(); 
	    $('#' +messageId + ' .audioSeek').bind("change", function() {
	        MessageAudioController.audio.currentTime = $(this).val();
	        $('#' +messageId + ' .audioSeek').attr("max", MessageAudioController.audio.duration);
	    });
    
    	MessageAudioController.play(); 
	//}
	}
	
		
}

MessageAudioController.setTotalDuration = function(messageId){
	var duration = MessageAudioController.audio.duration; 
	var sec = parseInt(duration % 60, 10);
	var min = parseInt((duration / 60) % 60, 10);
	if(min<10){
		min = '0'+min; //para que los minutos tengan siempre dos digitos
	}
	if(sec<10){
		sec = '0'+sec; //para que los minutos tengan siempre dos digitos
	};
	

	$('#' +messageId + ' .duration').html(min + ':' + sec); 
	$('#' +messageId + ' .audioSeek').attr('max',duration);
}

MessageAudioController.updateTime = function(messageId) {
	if(this.audio.paused){
		return;
	}

	$('#' +messageId + ' .audioSeek').attr('value',this.audio.currentTime);
}

MessageAudioController.play = function () {
	if (!MessageAudioController.audio){
	 	return; 
	}

	MessageAudioController.audio.play();
	MessageAudioController.playing= true;
	 
}

MessageAudioController.stop = function(){
	if (!MessageAudioController.audio){
	 	return; 
	}
	
	MessageAudioController.audio.pause();	
	MessageAudioController.playing = false;   
}
