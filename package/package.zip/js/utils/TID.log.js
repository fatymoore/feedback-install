/**
 * @fileOverview Logger implementation
 * @copyright   Copyright (c) 2009-2010 Telefónica I+D (http://www.tid.es)
 * @author      Iván -DrSlump- Montes <imv@tid.es>
 * @author      Rafael Oleza Alomar <roa@tid.es>
 * @version     $Id$
 */

/** @namespace */
var TID = TID || {};

/**
 * Logs a message using the configured log writer.
 *
 * Specialized versions are available in the form: TID.log._severity_ where
 * _severity_ is the lowercase version of the severity constants (following
 * log4j naming scheme):
 *
 *   * FATAL
 *   * ERROR
 *   * WARN
 *   * INFO
 *   * DEBUG
 *
 * @example
 * TID.log.error('My error message');
 * TID.log(TID.log.DEBUG, 'My debug message');
 *
 * @namespace
 * @param {Number} [severity]   Log severity. {@link TID.log.severity} if not given
 * @param {String} msg          Log message
 * @param {Mixed}  [...]        Variables for string interpolation
 */
TID.log = function(/*[severity,] msg, [ arg1, [arg2, [...]]]*/){
    var severity = TID.log.severity,
        from = 0;

    if (!TID.log.enabled) return;

    // Check if the log severity is supplied
    if (arguments.length > 1 && typeof arguments[0] === 'number') {
        // Extract the first argument as the severity
        severity = arguments[0];
        // Flag the first real argument index
        from = 1;
    }

    // Check if we have to log the message according to the current settings
    if (severity & TID.log.mask) {
        TID.log.writer(severity, Array.prototype.slice.call(arguments, from));
    }
};

// Build specialized logger methods and constants for each severity
(function(severities){
    for (var i=0; i<severities.length; i++) {
        (function(severity){
            TID.log[severity.toUpperCase()] = Math.pow(2, i);
            TID.log[severity.toLowerCase()] = function(){
                // Prepend the severity as the first argument
                var args = Array.prototype.slice.call(arguments, 0);
                args.unshift(TID.log[severity.toUpperCase()]);
                return TID.log.apply(TID.log, args);
            };
        })(severities[i]);
    }
})(['FATAL', 'ERROR', 'WARN', 'INFO', 'DEBUG']);


/**
 * Matches all logging priorities
 * @constant
 */
TID.log.ALL = 0xFF;

/**
 * Tells if log messages should be really processed or not.
 *
 * @type Boolean
 * @default true
 */
TID.log.enabled = true;

/**
 * Sets the masking level to use to allow or discard log messages.
 *
 * @example
 * // Log only warning, errors and fatals
 * TID.log.mask = TID.log.WARN | TID.log.ERROR | TID.log.FATAL
 * // Log everything but debug messages
 * TID.log.mask = TID.log.ALL ^ TID.log.DEBUG
 *
 * @type Number
 * @default TID.log.ALL
 */
TID.log.mask = TID.log.ALL;

/**
 * Default log severity to use where none is supplied when logging a message.
 *
 * @type Number
 * @default TID.log.INFO
 */
TID.log.severity = TID.log.INFO;


/**
 * Enables logging
 *
 * @see TID.log.enabled
 */
TID.log.enable = function(){
    TID.log.enabled = true;
};

/**
 * Disables logging
 *
 * @see TID.log.enabled
 */
TID.log.disable = function(){
    TID.log.enabled = false;
};

/**
 * Dummy writer, it should be overrided with an actual implementation.
 *
 * <p>Writers are encouraged to support Firebug's console logging
 * interpolation format. See http://getfirebug.com/console.html</p>
 *
 * @private
 * @param {Number} severity Severity constant
 * @param {Array}  args     Arguments to log
 */
TID.log.writer = function(severity, args){};


/**#nocode+*/

// Check if Firebug is available and if so use it as writer
if (typeof window !== 'undefined' &&
    typeof window.console !== 'undefined' &&
    typeof window.console.log === 'function') {

    TID.log.writer = function(severity, args){
        var func;

        switch (severity) {
        case TID.log.FATAL:
        case TID.log.ERROR:
            func = 'error';
            break;
        case TID.log.WARN:
            func = 'warn';
            break;
        case TID.log.INFO:
            func = 'info';
            break;
        case TID.log.DEBUG:
            func = (typeof window.console['debug'] === 'function') ? 'debug' : 'info';
            break;
        default:
            func = 'log';
        }

        window.console[func].apply(window.console, args);
    };
}

/**#nocode-*/

// Register the library in the OpenAjax hub
if (typeof OpenAjax !== 'undefined') {
    OpenAjax.hub.registerLibrary('TID.log', 'http://libs.tid.es/js/log', '1.0', {});
}
