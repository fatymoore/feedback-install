var Yarn = Yarn || {};

Yarn.Constants = {
    API_CONTENT_TYPE:   'application/json; charset=utf-8',
    API_ACCEPT:         'application/json',
    USER_AGENT:         'Yarn/1.2.45 (P; asus; Nexus 7; android; 4.1.1;)(1c6b120ce0943591)', //This would have to change.

    API_USERID:     '96711a88-3d4b-4a66-a009-1d25af7a0181',
    API_PASSWORD:   'L0nxFvjPyRvsYRtO',

    AUTH_BASIC:     'Basic ',
    AUTH_BEARER:    'Bearer ',

    /* URL's de los servicios de la API*/
    API_URL_REGISTER: API_URL + "/users/register",
    API_URL_VALIDATE: API_URL + "/users/validate",
    API_URL_GET_USER_INFO: API_URL + "/users/",
    API_URL_GET_AUTHENTICATION_TOKEN: API_URL + "/users/me/authorization",
    API_URL_LOGIN: API_URL + "/users/login",
    API_URL_LOGOUT: API_URL + "/users/me/logout",
    API_URL_GET_HISTORY: API_URL + "/users/{0}/history/?from_version=0&page_size=100&page_number=1",
    API_URL_GET_USER_CONTACTS: API_URL + "/users/{0}/contacts",
    API_URL_ADD_CONTACT: API_URL + "/users/{0}/contacts?check_duplicates=false",
    API_URL_GET_HISTORY_ITEM: API_URL + "/users/{0}/history/{1}?with_phone_number={2}",
    API_URL_GET_HISTORY_CONVERSATION: API_URL + "/users/{0}/history/?with_phone_number={1}",

    /* Ruta de los mocks */
    MOCK_AUTHORIZATION: MOCK_URL + 'authorization.json',
    MOCK_GET_USER_CONTACTS: MOCK_URL + 'contacts.json',
    MOCK_GET_USER_CONVERSATION: MOCK_URL + 'conversation.json',
    MOCK_GET_USER_HISTORY: MOCK_URL + 'history_simple.json',
    MOCK_REGISTER: MOCK_URL + 'register.json',
    MOCK_REPLIES: MOCK_URL + 'replies.json',
    MOCK_GET_USER_INFO: MOCK_URL + 'userInfo.json',
    MOCK_VALIDATE: MOCK_URL + 'validate.json',
    MOCK_RECENT_USERS: MOCK_URL + 'contactsVIP.json',
    MOCK_NEW_USERS: MOCK_URL + 'newContacts.json',

    /* SIP Connection produccion */
    /*     
    SIP_DOMAIN: 'yarnapp.com',
    SIP_PROXY: 'ws://195.235.93.155:443',
    */
    
    /* SIP Connection sandbox */
    SIP_DOMAIN: 'voip.ccsb.jajah.com',
    SIP_PROXY: 'ws://195.235.93.110:443',
    
    /* Template names */
    templates : {
        contacts : {
            idContainer : "contactsList",
            name : "tmpl_contacts_container" ,
            html : "templates/tmplContacts.html"
        },
        tmplUser : {
            name : "tmpl_user",
            html : "templates/tmplUser.html"
        },
        landing : {
            //idContainer : "pnl-landing-layout",
            name : "tmpl_landing_container" ,
            html : "templates/tmplLanding.html"
        },
        tmplConversation : {
            name : "tmpl_conversation_layout",
            html : "templates/tmplConversation.html"
        },
        tmplMessageText : {
            name : "tmpl_mesage_text",
            html : "templates/tmplMessageText.html"
        },
        tmplMessagePicture : {
            name : "tmpl_mesage_text_and_picture",
            html : "templates/tmplMessagePicture.html"
        },
        tmplMessageLocation : {
            name : "tmpl_mesage_location",
            html : "templates/tmplMessageLocation.html"
        },
        tmplMessageAudio : {
            name : "tmpl_message_audio",
            html : "templates/tmplMessageAudio.html"
        },
        tmplFoursquare : {
            name : "tmpl_foursquare_list" ,
            html : "templates/tmplFoursquare.html"
        }
    },

    GOOGLE_MAPS_COORDINATES:            'https://maps.google.com/maps?q=', /* add latitude,longitude */

    FOURSQUARE_COORDINATES:             'https://api.foursquare.com/v2/venues/search?ll=', /* add latitude,longitude */
    FOURSQUARE_CLIENT_ID:               '&client_id=', /* client_id */
    FOURSQUARE_VALUE_CLIENT_ID:         'YCKS0UTFFRTDXCXDBC15WQHGLNTWX2ICWH5FYMZNYDLIZD5R', /* value client_id */
    FOURSQUARE_CLIENT_SECRET:           '&client_secret=', /* client_secret */
    FOURSQUARE_VALUE_CLIENT_SECRET:     '5ATN0LXVHN1PBPQD3BK3AGAY032JNFCEMLNAF204EBLAILZD', /* value client_secret */
    FOURSQUARE_RADIUS_SEARCH:           '&radius=', /* radius maximun to search*/
    FOURSQUARE_METERS_RADIUS_SEARCH:    '250', /* radius maximun meters to search*/
    FOURSQUARE_LIMIT_SEARCH:            '&limit=', /* maximun results*/
    FOURSQUARE_VALUE_LIMIT_SEARCH:      '20', /* maximun value to results*/

    RTC_HEADER_COM_NOTIFICATIONS : 'delivered, displayed',
    RTC_HEADER_COM_TYPE_TEXT: 'text',
    RTC_HEADER_COM_TYPE_IMAGE: 'image',
    RTC_HEADER_COM_TYPE_LOCATION: 'location',
    RTC_HEADER_COM_TYPE_AUDIO: 'audio',
    RTC_HEADER_COM_LOGGING: 'on',
    RTC_HEADER_CONTENT_TYPE_TEXT: 'text/plain; charset=UTF-8',
    RTC_HEADER_CONTENT_TYPE_EXTERNAL_CONTENT: 'application/external-content+xml',
    RTC_HEADER_CONTENT_TYPE_GEOPOSITION: 'text/jj-geoposition',
    RTC_HEADER_ACCEPT_XML: 'text/plain, application/im-iscomposing+xml'
};
