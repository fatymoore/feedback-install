var Yarn = Yarn || {};

Yarn.TextConversions = (function() {
    var HtmlCodes = [['ñ', '&#241;'],
                     ['Ñ', '&#209;'],
                     ['á', '&#225;'],
                     ['é', '&#233;'],
                     ['í', '&#237;'],
                     ['ó', '&#243;'],
                     ['ú', '&#250;']];

    var SpecialChars = [['<', '&lt;'],
                        ['>', '&gt;'],
                        ['&', '&amp;'],
                        ['"', '&quot;']];

    /**
     * Replace Text on a String
     * We use a RegExp because is 85% faster than a recursive search:
     * http://jsperf.com/replacing-text
     * @param  {string} text      The text where search a string to replace
     * @param  {string} search    The string to search for replace in the original
     * @param  {string} newstring The new string
     * @return {string}           The string already replaced
     */
    function _replaceAll ( text, search, newstring ) {
      var pattern = new RegExp( search, 'gi' );
      return text.toString().replace( pattern, newstring );
    }
    
    /**
     * Delete HTML Label on a String
     * We use a RegExp because is 85% faster than a recursive search:
     * http://jsperf.com/replacing-text
     * @param  {string} text      The text where search a label to replace
     * @param  {string} search    The label to search for replace in the original
     * @return {string}           The string already replaced
     * 
     * For example,<a href="mailto:a@tid.es">&g@tid.es</a>, result is a@tid.es
     */
    
    function _deleteHTMLLabel ( text, search ) {
    	var indexFirst = text.toString().indexOf(search);

    	while (indexFirst != -1) {
    		var indexLast = text.toString().indexOf (">", indexFirst + 1);
    		var cadenaDelete = text.substring(indexFirst, indexLast + 1);
    		text = _replaceAll(text, cadenaDelete, '');

    		indexFirst = text.toString().indexOf(search);
    	}

    	return text;
    }

    /**
     * returns the text with all the html craracters
     * defined in HtmlCode
     * @param {Object} text
     */
    function _replaceSpecialCharacters( text ) {
      var finalText = text;
      $.each(HtmlCodes, function( index, value ) {
        finalText = _replaceAll(finalText, value[0], value[1]);
      });

      return finalText;
    }

    function _addCharacters(text, character, length) {
        while(text.toString().length < length) {
            text = character + text;
        }
        return text;
    }

    /**
    * String left padding
    */
    function _padding(text, character, length) {
        return String(character + text).slice(-length);
    }

    /**
     * This function will replace only the above characters
     * @param {Object} text
     */
    function _escapeSpecialCharacters(text){
        var finalText = text;
        $.each(SpecialChars, function( index, value ) {
            finalText = _replaceAll(finalText, value[0], value[1] );
        });
        return finalText;
    }
    
    /**
     * This function will search number in the string
     * @param {Object} text
     */
    function _possiblePhoneNumber(text) {
    	var numbers = "0123456789";

    	for (i=0; i < texto.length; i++) {
    		if (numbers.indexOf(texto.charAt(i),0) != -1) {
    			return true;
    		}
    	}

    	return false;
    }

    return {
            replaceAll: _replaceAll,
            replaceSpecialCharacters: _replaceSpecialCharacters,
            addCharacters: _addCharacters,
            escapeSpecialCharacters: _escapeSpecialCharacters,
            padding: _padding,
            deleteHTMLLabel: _deleteHTMLLabel,
            possiblePhoneNumber: _possiblePhoneNumber,
    };

})();

