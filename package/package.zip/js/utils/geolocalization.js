var Yarn = Yarn || {};

Yarn.Geo = {

	currentLatitude: null,
	currentLongitude: null,
	currentAddress: null,
	namePlace: null,
	idElem: null,
	watchId: null,
	map: null,

	/* divElement is the element which the map will be appended */
	drawMap: function(divElement) {
		this.idElem = divElement;

		if (navigator.geolocation) {
			this.watchId = navigator.geolocation.watchPosition(success, error);
		} else {
			this.error('not supported');
		}
	}, 

	success: function(position) {
		conversationView.refreshAddressBox('', i18n.getPropertyValue('searchLocation'));

		var domElem = $(Yarn.Geo.idElem); 

		var mapcanvas = document.createElement('div');
		mapcanvas.id = 'mapcanvas';
		mapcanvas.style.height = domElem.height()+'px';
		mapcanvas.style.width = domElem.width() +'px';

		$(Yarn.Geo.idElem).html(mapcanvas); //TODO es necesario recorrer todo el DOM? no podemos pasar directamente el elemento? 

		Yarn.Geo.currentLatitude = position.coords.latitude; 
		Yarn.Geo.currentLongitude = position.coords.longitude; 
		var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude); 

		var myOptions = {
			zoom: 15,
			center: latlng,
			mapTypeControl: false,
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			disableDefaultUI : true
		};

		var map = new google.maps.Map(document.getElementById("mapcanvas"), myOptions);

		var markerOriginal = new google.maps.Marker({
			map: map,
			position: latlng,
			visible: true,
		});	

		var urlFoursquare = 	Yarn.Constants.FOURSQUARE_COORDINATES + Yarn.Geo.currentLatitude + ',' + Yarn.Geo.currentLongitude + 
								Yarn.Constants.FOURSQUARE_RADIUS_SEARCH + Yarn.Constants.FOURSQUARE_METERS_RADIUS_SEARCH + 
								Yarn.Constants.FOURSQUARE_LIMIT_SEARCH + Yarn.Constants.FOURSQUARE_VALUE_LIMIT_SEARCH + 
								Yarn.Constants.FOURSQUARE_CLIENT_ID + Yarn.Constants.FOURSQUARE_VALUE_CLIENT_ID + 
								Yarn.Constants.FOURSQUARE_CLIENT_SECRET + Yarn.Constants.FOURSQUARE_VALUE_CLIENT_SECRET;

		Yarn.Geo.map = new Array();

		/* Query foursquare API for venue recommendations near the current location. */
		$.getJSON(urlFoursquare, {}, function(data) {
			venues = data['response']['groups'][0]['items'];
			/* Place marker for each venue. */
			venues.forEach(Yarn.Geo.searchFoursquareMarker);
		});

		Yarn.Geo.getCurrentAddress('');
	},

	searchFoursquareMarker: function(place) {
		/* Get marker's location */
		var latLng = new google.maps.LatLng( 
			place['location']['lat'],
			place['location']['lng']
		);

		if (place['categories']['0']){
			var urlIcon = place['categories']['0']['icon']; 
		}else{
			var urlIcon = '../img/maqueta/super-icono.jpg'; 
		}

		var marker = new google.maps.Marker({
			id: place['id'],
			position: latLng,
			title: place['name'],
			icon: urlIcon,
			visible: false,
			address: place['location']['address'],
			distance: place['location']['distance'],
			lat: place['location']['lat'],
			lng: place['location']['lng'],
		});

		google.maps.event.addListener(marker, 'click', function () {
			Yarn.Geo.currentLatitude = this.position.lat();
			Yarn.Geo.currentLongitude = this.position.lng();

			Yarn.Geo.getCurrentAddress(this.title);
		});

		Yarn.Geo.map.push(marker);
	},

	error: function (txt) {
		TID.log.debug('Geolocalization error: ' + txt);
	}, 	
	
	showLocationAsImageMessage:function(elem, latitude, longitude){
		var domElem = $(elem); 

		var mapcanvas = document.createElement('div');
		mapcanvas.id = 'mapcanvasImg' + elem;
		mapcanvas.style.height ='120px';
		mapcanvas.style.width = '354px';

		domElem.html(mapcanvas); 

		var latlng = new google.maps.LatLng(latitude, longitude);
		var myOptions = {
			zoom: 16,
			center: latlng,
			mapTypeControl: false,
			mapTypeId: google.maps.MapTypeId.ROADMAP, 
			disableDefaultUI : true
		};

		new google.maps.Map(document.getElementById("mapcanvasImg"+ elem), myOptions);
	}, 
	
	getCurrentAddress: function(titleName){
		var latlng = new google.maps.LatLng(Yarn.Geo.currentLatitude, Yarn.Geo.currentLongitude);
		var geocoder = new google.maps.Geocoder();

		geocoder.geocode({'latLng': latlng}, function(results, status) {
			if (status == google.maps.GeocoderStatus.OK) {
				Yarn.Geo.currentAddress = results[0].formatted_address;
				Yarn.Geo.namePlace = titleName;
				conversationView.enableChatButton();	
			} else if (status == google.maps.GeocoderStatus.ZERO_RESULTS){
					$('#locationSearchBox').html('<span>' + i18n.getPropertyValue('problemWithMap') + '</span>');
				} 
				else{
					TID.log.error("Geocoder failed due to: " + status);
				}
		});
	}
}

function success(position){
	navigator.geolocation.clearWatch(Yarn.Geo.watchId);
	Yarn.Geo.success(position);
}

function error(){
	alert("error en localizacion");
}

