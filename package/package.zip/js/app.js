_.templateSettings = {
  evaluate: /\[\[([\s\S]+?)\]\]/g,
  interpolate: /\{\{(.+?)\}\}/g // Moustache.js style
};

var App = App || {};

$(document).ready(function() {
    initMainPage();
    mainView.createRouter();
});

App.Layout = {
    contactsPanelBottomSpace: 55,
    contactsPanelWidth: 300,
    mio: 75,

    recalculate: function() {
        // MAIN LAYOUT
        var portalWidth = $(window).width();
        var portalHeight = $(window).height();
        $('#mainFrame').css({ height: portalHeight + 'px' });

        $('#contactsPanel').css({ height: (portalHeight - this.contactsPanelBottomSpace - 170) + 'px'});

        var conversation_width = portalWidth - 330;
        $('#mainRightPanel').css({ width: conversation_width + 'px' });

        // CONVERSATION
        $('#conversationPanel').css({ height: (portalHeight - 170) + 'px' });
        $('#chatpane').css({ height: (portalHeight - 300) + 'px' });

        //window.ConversationView.calculateTopMargin();
        App.Layout.conversationTopMargin();

        // GENERAL SECTION
        $('#section-content').css({ height: (portalHeight - 170) + 'px' });
        
        // SETTINGS LAYER
        $('#bottomMainContainer').css({ height: (portalHeight - 48) + 'px' });
        $('#bottomMainContainer').css({ width: conversation_width + 'px' });
        $('#settings-content').css({ height: (portalHeight - 148) + 'px' });
        
    },
    conversationTopMargin: function() {
        var conversationHeight = $('#conversation').height();
        var chatpaneHeight = $('#chatpane').height();

        if (conversationHeight < chatpaneHeight) {
            var margen = chatpaneHeight - conversationHeight;
            $('#conversation').css('margin-top', margen);
        }else {
            $('#conversation').css('margin-top', 0);
        }
    },
    showSettingsPanel: function() {
        //$('#bottomMainContainer').fadeIn(400);
        
        console.log("showSettingsPanel");
        
        var altoPanel = $('#bottomMainContainer').height();
        $('#bottomMainContainer').css('bottom', -altoPanel);
        $('#bottomMainContainer').css('display', 'block');
        $('#bottomMainContainer').animate({bottom: 0}, 500, function() {
            //$('#addContactPanel').fadeIn(400);
        });
      
    },
    hideSettingsPanel: function() {
        console.log("hideSettingsPanel");
        

        var altoPanel = $('#bottomMainContainer').height();
        $('#bottomMainContainer').animate({bottom: -altoPanel}, 250, function() {
            $('#bottomMainContainer').css('display', 'none');     
        });
    }
};

$(window).resize(function() {
  App.Layout.recalculate();
});
