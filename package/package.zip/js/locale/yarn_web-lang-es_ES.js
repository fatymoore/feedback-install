
/**
 * property-value for SPANISH  
 */
var i18n_ES = {
 	'dragPhotos' : 'Arrasta aquí tus fotos',
 	'status': [ //consider MessageStatus order
 		'enviando', 'enviado', 'recibido', 'no enviado',  'reenviando'
 	],
 	'recordMessage':		 'Grabe un mensaje',
 	'pictureDefaultCaption': '¡foto enviada!',
 	'statusConnecting':		 'Conectando...',

 	/*conversationView*/
 	'clickLocation':	'Pulsa en la burbuja para una nueva localizacion',
 	'loadingText': 		'Cargando... ', 
 	'errorLoad': 		'Imagen no soportada ',
 	'errorEmptyImage':	'Imagen vacia',

	/*conversationView*/
 	'searchLocation':	'Pulsa aqui para buscar lugares cercanos...',
 	'problemWithMap':	'Existe algun problema al calcular tu localizacion. Intentalo de nuevo',

 	/*errorLocalStorage*/
 	'fullLocalStorage':	'Excedido el limite de almacenamiento del LocalStorage. Limpiando... ',

 	/*Register error*/
 	'errorInvalidPhoneNumber':	'Por favor, introduce un numero valido, formato: 34<numero telefono>',
 	'errorRegister':			'Existe un error con el registro, comprueba que el formato es: 34<numero telefono>',
 	'errorInvalidCode':			'Codigo invalido. Intentalo de nuevo o pulsa "Llamame con el codigo"',
 	//'errorEmptyName':			'Por favor, introduce un nombre',
 	//'errorUpdateName':		'Existe un problema mientras se actualiza el nombre',
 	
 	/* HTTP Error*/
 	'500': 'Error Interno',
 	
};
