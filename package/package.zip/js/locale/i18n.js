
/**
 * I18n controller 
 */
var i18n = {
	
	currentLanguage: "ES" 
	
	,changeLanguage: function(newLang){
		this.currentLanguage=newLang; 
	}
	
	,getPropertyValue:function(property){
		return languages[this.currentLanguage][property]; 
	}
}


/**
 *This variable will contain all the possible languages supported by this application  
 */
var languages = {
	"ES" :  i18n_ES,
	"EN" :  i18n_EN
};


