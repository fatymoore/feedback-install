
/**
 * property-value for ENGLISH
 */
var i18n_EN = {
 	'dragPhotos' : 'Drag images here', 
 	'status': [
 		'Sending','Sent','Received', 'Not Sent', 'Re-sending'
 	],

 	'recordMessage':		'Record a message',
 	'pictureDefaultCaption':'picture sent!',
 	'statusConnecting':		'Connecting...',

 	/*conversationView*/
 	'clickLocation':	'Click icon bellow for a new location',
 	'loadingText': 		'Loading... ',
 	'errorLoad': 		'Not allow this type of image',
 	'errorEmptyImage':	'Empty Image', 	

	/*conversationView*/
 	'searchLocation':	'Click here to search recommendation location...',
 	'problemWithMap':	'Problems to calculate location. Try again',

 	/*errorLocalStorage*/
 	'fullLocalStorage':	'MAXIMUM LIMIT IN LocalStorage REACHED. Cleaning... ',

 	/*Register error*/
 	'errorInvalidPhoneNumber':	'Please enter a valid number, format 34<phone number> ',
 	'errorRegister':			'There has been an error with the registration, format 34<phone number>',
 	'errorInvalidCode':			'Code not recognized. Please try again or press "Call me with the code"',
 	//'errorEmptyName':			'Please enter a name',
 	//'errorUpdateName':		'There has been an error while updating your name',
 	
 	/* HTTP Error*/
 	'500': 'Internal Error',
 	
}
