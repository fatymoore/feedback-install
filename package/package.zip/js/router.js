AppRouter = Backbone.Router.extend( {

    routes: {
        'inboxScreen' : 'showInboxScreen',
        'conversation/:userName/:msisdn/:userAvatar' : 'showConversation',
        'addContact' : 'addContact',
        'closeAddContact' : 'closeAddContact',
        'settings' : 'showSettings',
        'blank': 'showBlank'
    },

    initialize: function () {
       TID.log.debug('initialize AppRouter');
    },

    showInboxScreen: function () {
        // Mocking cookies
        if ( MOCK === true ) {
            $.cookie( 'username', '34646014586' );
            $.cookie( 'password', '8DioZJZqjIIYkZSn' );
        }

        var user = $.cookie('username'),
            password = $.cookie('password');

		if ( user && password ) {
            initLandingPage();
            App.inboxView = new App.InboxView();
		} else {
			this.gotoLoginPage();
		}
    },

    gotoLoginPage: function () {
        window.location = "register.html";
    },

    addContact: function () {
        var portalHeight = $(window).height(),
            alto;

        $('#btnAddContact').addClass('selected');
        App.Layout.contactsPanelBottomSpace = $('#addContactPanel').height() + 55;
        alto = portalHeight - App.Layout.contactsPanelBottomSpace - 175;

        // hide contacts scroll
        $('#contactsPanel').css('overflow-y', 'hidden');
        $('#contactsLoadLayer').fadeIn(400);
        $('#contactsPanel').animate({
            height: alto
          }, 300, function () {
            $('#addContactPanel').fadeIn(400);
        });
    },

    closeAddContact: function () {
        var portalHeight = $(window).height(),
            alto;

        App.Layout .contactsPanelBottomSpace = 55;
        alto = portalHeight - App.Layout .contactsPanelBottomSpace - 175;

        $('#addContactPanel').fadeOut( 300, function () {
            $('#contactsLoadLayer').fadeOut( 300, function () {
                $('#btnAddContact').removeClass('selected');
            } );
            $('#contactsPanel').animate( {
                height: alto
            }, 300, function () {
                // show contacts scroll
                $('#contactsPanel').css('overflow-y', 'scroll');
            } );
        });
    },

    showConversation: function ( userName,  msisdn, avatar ) {
        var template = $('#tmpl_conversation_layout').html();
        $('#mainRightPanel').html( template );
        document.getElementById('user-name').innerHTML = userName;
        $('#user-picture').css( 'background-image', 'url("img/avatars/' + avatar + '")' );
        initConversationPage( msisdn, 'mainRightPanel' );
        App.Layout.recalculate();
    },

    showSettings: function() {
        console.log("AppRouter -- showSettings");
        $('#bottomContent').load( 'templates/module-settings-main.html', window.App.Layout.recalculate );
        window.App.Layout.showSettingsPanel();
    },

    backSettingsPanel: function() {
        console.log("AppRouter -- backSettingsPanel");
        // Fast
        // $('#bottomContent').load('templates/module-settings-main.html', window.App.Layout.recalculate);
        //Slow
        $('#bottomContent').fadeOut(200, function() {
            $('#bottomContent').load('templates/module-settings-main.html', window.App.Layout.recalculate);
            $('#bottomContent').fadeIn(200);
        });
        $('#btnSettingsBack').fadeOut(200);
    },

    showAddMinutesPanel: function() {
        console.log("AppRouter -- showAddMinutesPanel");
        // Fast
        // $('#bottomContent').load('templates/module-settings-add-ninutes.html', window.App.Layout.recalculate);
        // Slow
        $('#bottomContent').fadeOut(200, function() {
            $('#bottomContent').load('templates/module-settings-add-ninutes.html', window.App.Layout.recalculate);
            $('#bottomContent').fadeIn(200);
        });
        $('#btnSettingsBack').fadeIn(200);
    },

    showBlank: function() {
        TID.log.debug('---> Router GOTO: blank');
    },

    defaultRoute: function ( other ) {
        TID.log.debug('Invalid. You attempted to reach:' + other);
    }

} );
