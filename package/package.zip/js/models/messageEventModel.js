
var MessageStatus = {
	sending: 0, 
	sent : 1, 
	received : 2, 
	error: 3, 
	resend: 4
}; 

/**
 * Message Event, extends from Event class.  
 */
var MessageEvent = Event.extend({
	body: null,
	status: null,
	urlRoot : '/user', 
	callId: null,

	//Backbone doesn't allow more than one constructor
	initialize : function(eventType) {
		this.status = MessageStatus.sending; 
		this.constructor.__super__["createEvent"].call(this,eventType,"", DirectionType[0], null);
	},

	setMessage: function (textMessage){
		this.body = textMessage; 
		//this.save();
	},

}); 


/**
 * User's contacts will be a list of  "User" objects 
 */
var MessagesList = Backbone.Collection.extend({
	model: MessageEvent
});