

var EventType = {
	call: 0,
	text : 1,
	image: 2,
	location: 3,
	contact : 4,
	audio : 5
};

var DirectionType =["send", "receive"];

var Event = Backbone.Model.extend({
	eventId: null, //jajah id which is the backbone model id
	commId: null, // Comm-Id returned by jajah and received in notifications
	eventType: null,
	timeReceived : null, //DATE
	isWith : null,
	direction : null, //DirectionType
	eventPosition: null, //geolocalization
	read : false,
	deleted: false,
	remoteId: null,

	initialize : function(eventType, isWith,direction,geoLocalization){
		this.eventId = this.cid;
		this.eventType = eventType;
		this.isWith = isWith;
		this.direction = direction;
		this.eventPosition = geoLocalization;
		this.timeReceived  = getCurrentUTCTime();
	},

	createEvent: function(eventType, isWith,direction,geoLocalization){
		this.eventId = this.cid;
		this.eventType = eventType;
		this.isWith = isWith;
		this.direction = direction;
		this.eventPosition = geoLocalization;
		this.timeReceived  = getCurrentUTCTime();

	}
});