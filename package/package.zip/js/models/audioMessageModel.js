/**
 * Audio Message, extends from Message Event, which extends from Event 
 */
var AudioMessage = MessageEvent.extend({

	duration : null,
	localPath : null,
	remotePath : null,
	uri : null,
	
	initialize : function(){
		this.constructor.__super__["initialize"].call(this,EventType.audio);
		this.uri=''; 
	}
}); 
