var UserModel = Backbone.Model.extend({
	userId : null,
	identifier: null,
	screenName: null,
	presence: null,
	msisdn : null,
	unreadCalls : null,
	unreadMessages: null,
	unreadPhotos: null,
	unreadLocation: null,
	unreadAudioRecords : null,
	unreadContacts: null, //is this necessary? iOS version has it, Android not
	lastEvent : null,

	initialize : function ( lastEvent ) {
		this.lastEvent = lastEvent;
		this.presence = Yarn.PresenceStatus.Offline;
	},

	isOnline : function ( username ) {
		return this.presence == Yarn.PresenceStatus.Online;
	},

	toString : function () {
		return this.identifier + " - " + this.screenName + " - " + this.userId;
	}
});
