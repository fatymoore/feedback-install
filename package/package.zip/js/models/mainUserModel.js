var User = Backbone.Model.extend({
	userId : null,
	identifier: null,
	screenName: null,
	presence: null,
	msisdn : null,
	unreadCalls : null,
	unreadMessages: null,
	unreadPhotos: null,
	unreadLocation: null,
	unreadAudioRecords : null,
	unreadContacts: null, //is this necessary? iOS version has it, Android not
	lastEvent : null,

	initialize : function ( lastEvent ) {
		this.lastEvent = lastEvent;
		this.presence = PresenceStatus.Offline;
	},

	getAllUnread : function () {
		return  this.unreadCalls +
            this.unreadMessages +
            this.unreadPhotos +
            this.unreadLocations +
            this.unreadAudioRecords +
            this.unreadContacts;
	},

	isOnline : function ( username ) {
		return this.presence == PresenceStatus.Online;
	},

	toString : function () {
		return this.identifier + " - " + this.screenName + " - " +this.userId;
	}

});