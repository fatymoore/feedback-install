var LandingModel = Backbone.Model.extend({
	userId : null,
	recentUsers : null,
	newUsers : null,
	suggestedPeople : null, 

	initialize : function() {
		this.recentUsers = new Array(); 
		this.newUsers = new Array(); 
		this.suggestedPeople = new Array(); 
	},

}); 

