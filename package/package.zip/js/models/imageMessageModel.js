

var Thumbnail = Backbone.Model.extend({

	id : null,
	content : null,
	initialize : function(content) {
		this.content = content; 
	}
	
}); 

/**
 * Image Message, extends from Message Event, which extends from Event 
 */
var ImageMessage = MessageEvent.extend({

	duration : null,
	thumbnail : null,
	caption : null,
	toInsertThumbnail : null,
	localPath : null,
	remotePath : null,
	uri : null,
	width: null, 
	height: null, 
	
	initialize : function() {
		this.toInsertThumbnail = new Thumbnail(null); 
		this.caption=i18n.getPropertyValue("pictureDefaultCaption");  
		this.constructor.__super__["initialize"].call(this,EventType.image);
		this.uri="not loaded";
	},
	parseContent: function(content) {
		//TODO this is done on Android version. Do we need it here? 
	}
}); 
