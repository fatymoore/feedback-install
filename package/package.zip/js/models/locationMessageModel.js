/**
 *  Location Message, extends from Message Event, which extends from Event 
 */
var LocationMessage = MessageEvent.extend({

	latitude : null,
	longitude : null,
	address : null,
	
	//TODO Backbone doesn't allow more than one constructor, fix it!
	initialize : function(){
		
		this.constructor.__super__["initialize"].call(this,EventType.location);
	
	}

}); 
