var CallStatus = {
    notConnected: -1,
    unknown: 0,
    received: 2,
    establishing: 3,
    established : 4,
    cleared : 5,
    rejected : 6 ,
    cancelled : 7,
    calling : 8,
    notFound : 404,
    busy : 486,
    decline : 603
};


/**
 * Call Event, extends from Event class.
 */
var CallEvent = Event.extend({
    callId: null,
    duration: null,
    quality : null,
    status : null,
    type : null,

    initialize : function(){
        TID.log.debug("Init 'CallEvent' 1");

        this.constructor.__super__["initialize"].call(this,EventType.call,"", DirectionType.send, null);
        this.type = 0;
        this.status = CallStatus.unknown;
        this.quality = "";
        this.duration = 0;
    }

});
