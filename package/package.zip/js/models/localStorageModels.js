function LocalStorageMessage() {
	this.cid = null;
	this.callId = null;
	this.body = null;
	this.status = null;
	this.eventId = null;
	this.eventType = null;
	this.timeReceived  = null;
	this.isWith  = null;
	this.direction  = null;
	this.eventPosition = null;
	this.read = null;
	this.deleted = null;
	this.remoteId = null;
}

function LocalStorageModel() {
	this.userId =  null;
	this.identifier=  null;
	this.screenName=  null;
	this.presence=  null;
	this.msisdn =  null;
	this.unreadCalls =  null;
	this.unreadMessages=  null;
	this.unreadPhotos=  null;
	this.unreadLocation=  null;
	this.unreadAudioRecords=  null;
	this.unreadContacts=  null;
	this.lastEvent =  null;
}

var Parser = {};

Parser.UserModelToObject = function ( model ) {
	var obj = new LocalStorageModel();
	obj.userId =  model.userId;
	obj.identifier=  model.identifier;
	obj.screenName=  model.screenName;
	obj.presence=  model.presence;
	obj.msisdn =  model.msisdn;
	obj.unreadCalls =  model.unreadCalls;
	obj.unreadMessages=  model.unreadMessages;
	obj.unreadPhotos=  model.unreadPhotos;
	obj.unreadLocation=  model.unreadLocation;
	obj.unreadAudioRecords=  model.unreadAudioRecords;
	obj.unreadContacts=  model.unreadContacts;
	obj.lastEvent =  model.lastEvent;
	return obj;
};

Parser.UserObjectToBackboneModel = function ( object ) {
	var model = new LocalStorageModel();
	model.userId =  object.userId;
	model.identifier=  object.identifier;
	model.screenName=  object.screenName;
	model.presence=  object.presence;
	model.msisdn =  object.msisdn;
	model.unreadCalls =  object.unreadCalls;
	model.unreadMessages=  object.unreadMessages;
	model.unreadPhotos=  object.unreadPhotos;
	model.unreadLocation=  object.unreadLocation;
	model.unreadAudioRecords=  object.unreadAudioRecords;
	model.unreadContacts=  object.unreadContacts;
	model.lastEvent =  object.lastEvent;
	return model;
};

Parser.TextMessageModelToObject = function ( model ) {
	var obj = new LocalStorageMessage();
	obj.cid = model.cid;
	obj.callId = model.callId;
	obj.commId = model.commId;
	obj.body = model.body;
	obj.status = model.status;
	obj.eventId = model.eventId;
	obj.eventType = model.eventType;
	obj.timeReceived  = model.timeReceived;
	obj.isWith  = model.isWith;
	obj.direction  = model.direction;
	obj.eventPosition = model.eventPosition;
	obj.read = model.read;
	obj.deleted = model.deleted;
	obj.remoteId = model.remoteId;

	return obj;
};


Parser.LocationMessageModelToObject = function ( model ) {
	var obj = Parser.TextMessageModelToObject(model);
	obj.latitude = model.latitude;
	obj.longitude = model.longitude;
	obj.address = model.address;
	obj.namePlace = model.namePlace;

	return obj;
};

Parser.MessageObjectToBackboneModel = function( object ) {

	var model = null;

	if ( object.eventType == EventType.text ) {
		model = new MessageEvent( object.eventType );
	} else if ( object.eventType == EventType.image ) {
		model = new ImageMessage();
	} else if ( object.eventType == EventType.location ) {
		model = new LocationMessage();
	} else if ( object.eventType == EventType.audio ) {
		model = new AudioMessage();
	}
	model.cid = object.cid ;
	model.callId = object.callId ;
	model.commId = object.commId ;
	model.body = object.body ;
	model.status = object.status;
	model.eventId = object.eventId;
	model.timeReceived  = object.timeReceived;
	model.isWith  = object.isWith;
	model.direction  = object.direction;
	model.eventPosition = object.eventPosition;
	model.read = object.read;
	model.deleted = object.deleted;
	model.remoteId = object.remoteId;

	if ( object.eventType == EventType.image ) {
		model.duration = object.duration;
		model.thumbnail = object.thumbnail;
		model.caption = object.caption;
		model.toInsertThumbnail = object.toInsertThumbnail;
		model.localPath = object.localPath;
		model.remotePath = object.remotePath;
		model.uri = object.uri;
		model.width = object.width;
		model.height = object.height;
	}

	if ( object.eventType == EventType.location ) {
		model.latitude = object.latitude;
		model.longitude = object.longitude;
		model.address = object.address;
		model.namePlace = object.namePlace;
	}

	if ( object.eventType == EventType.audio ) {
		model.duration = object.duration;
		model.localPath = object.localPath;
		model.remotePath = object.remotePath;
		model.uri = object.uri;
	}

	return model;
};
